"""
Fingerprint Matching Engine Module for Website Fingerprinting Attack Simulator.
Implements transparent, non-machine-learning statistical distance comparisons
with feature weighting, multi-sample aggregation, and confidence calibration notices.
"""

import os
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"

import math
from typing import Dict, Any, List, Optional, Tuple
import numpy as np

def relative_similarity(val1: float, val2: float, scale_factor: float = 1.0) -> float:
    """
    Computes a symmetric relative similarity in [0.0, 1.0] between two non-negative scalar values.
    Uses: 1 - (|a - b| / (max(a, b) + epsilon))
    """
    if val1 == 0.0 and val2 == 0.0:
        return 1.0
    denom = max(abs(val1), abs(val2))
    if denom <= 1e-9:
        return 1.0
    diff = abs(val1 - val2)
    sim = max(0.0, 1.0 - (diff / denom) * scale_factor)
    return round(float(sim), 4)

def log_scale_similarity(val1: float, val2: float) -> float:
    """
    Computes similarity using logarithmic scaling to prevent large numbers
    (e.g., total bytes) from dominating the comparison.
    """
    if val1 <= 0 and val2 <= 0:
        return 1.0
    log1 = math.log10(max(1.0, val1))
    log2 = math.log10(max(1.0, val2))
    denom = max(log1, log2)
    if denom <= 1e-9:
        return 1.0
    diff = abs(log1 - log2)
    return round(max(0.0, 1.0 - (diff / denom)), 4)

def vector_l1_similarity(vec1: List[float], vec2: List[float]) -> float:
    """
    Computes L1 histogram intersection / similarity in [0.0, 1.0] for two normalized vectors.
    Sim = 1 - 0.5 * sum(|v1_i - v2_i|)
    """
    if not vec1 or not vec2:
        return 0.0
    length = min(len(vec1), len(vec2))
    l1_diff = sum(abs(vec1[i] - vec2[i]) for i in range(length))
    # Since normalized vectors sum to 1.0, max L1 difference is 2.0
    sim = max(0.0, 1.0 - (0.5 * l1_diff))
    return round(float(sim), 4)

def cosine_similarity(vec1: List[float], vec2: List[float]) -> float:
    """Computes cosine similarity between two numeric vectors."""
    a = np.array(vec1, dtype=float)
    b = np.array(vec2, dtype=float)
    norm_a = np.linalg.norm(a)
    norm_b = np.linalg.norm(b)
    if norm_a == 0 or norm_b == 0:
        return 1.0 if norm_a == norm_b else 0.0
    cos = np.dot(a, b) / (norm_a * norm_b)
    return round(float(np.clip(cos, 0.0, 1.0)), 4)


class FingerprintMatcher:
    """
    Compares an unknown fingerprint against stored reference website fingerprints.
    """

    def __init__(self, reference_fingerprints: List[Dict[str, Any]]):
        self.references = reference_fingerprints

    def compare_pair(self, fp_unknown: Dict[str, Any], fp_ref: Dict[str, Any]) -> Dict[str, Any]:
        """
        Calculates detailed, multi-component similarity between two fingerprints.
        Returns component scores and weighted overall similarity in [0, 100].
        """
        # 1. Packet Size Histogram Similarity (L1 Manhattan Intersection)
        hist_sim = vector_l1_similarity(
            fp_unknown.get("size_histogram_normalized", []),
            fp_ref.get("size_histogram_normalized", [])
        )

        # 2. Temporal Traffic Volume Distribution Similarity
        time_sim = cosine_similarity(
            fp_unknown.get("time_volume_normalized", []),
            fp_ref.get("time_volume_normalized", [])
        )

        # 3. Packet Size Statistical Summary Similarity
        mean_sim = relative_similarity(fp_unknown.get("mean_packet_len", 0), fp_ref.get("mean_packet_len", 0))
        median_sim = relative_similarity(fp_unknown.get("median_packet_len", 0), fp_ref.get("median_packet_len", 0))
        std_sim = relative_similarity(fp_unknown.get("std_packet_len", 0), fp_ref.get("std_packet_len", 0))
        size_stats_sim = round((mean_sim + median_sim + std_sim) / 3.0, 4)

        # 4. Traffic Volume Similarity (Log-scaled)
        byte_sim = log_scale_similarity(fp_unknown.get("total_bytes", 0), fp_ref.get("total_bytes", 0))
        pkt_sim = log_scale_similarity(fp_unknown.get("total_packets", 0), fp_ref.get("total_packets", 0))
        volume_sim = round((byte_sim + pkt_sim) / 2.0, 4)

        # 5. Timing and Rate Similarity
        iat_sim = relative_similarity(fp_unknown.get("mean_iat", 0), fp_ref.get("mean_iat", 0))
        dur_sim = relative_similarity(fp_unknown.get("duration", 0), fp_ref.get("duration", 0))
        rate_sim = relative_similarity(fp_unknown.get("packet_rate", 0), fp_ref.get("packet_rate", 0))
        timing_sim = round((iat_sim + dur_sim + rate_sim) / 3.0, 4)

        # 6. Directional Ratio Similarity (Conditional)
        has_u_dir = fp_unknown.get("has_direction_knowledge", False)
        has_r_dir = fp_ref.get("has_direction_knowledge", False)
        dir_sim = 0.0
        use_direction = has_u_dir and has_r_dir

        if use_direction:
            u_ratio = fp_unknown.get("direction_ratio", 0.0)
            r_ratio = fp_ref.get("direction_ratio", 0.0)
            dir_sim = max(0.0, 1.0 - abs(u_ratio - r_ratio))
            dir_sim = round(float(dir_sim), 4)

        # Weighted aggregation with dynamically re-normalized weights
        if use_direction:
            w_hist, w_time, w_size, w_vol, w_timing, w_dir = 0.25, 0.20, 0.20, 0.15, 0.10, 0.10
        else:
            # Re-normalize without directional feature
            w_hist, w_time, w_size, w_vol, w_timing, w_dir = 0.28, 0.22, 0.22, 0.17, 0.11, 0.0

        overall_sim = (
            (hist_sim * w_hist) +
            (time_sim * w_time) +
            (size_stats_sim * w_size) +
            (volume_sim * w_vol) +
            (timing_sim * w_timing) +
            (dir_sim * w_dir)
        )

        overall_score = round(max(0.0, min(100.0, overall_sim * 100.0)), 2)

        return {
            "overall_similarity": overall_score,
            "components": {
                "size_histogram": round(hist_sim * 100, 2),
                "temporal_profile": round(time_sim * 100, 2),
                "packet_size_stats": round(size_stats_sim * 100, 2),
                "traffic_volume": round(volume_sim * 100, 2),
                "timing_and_rates": round(timing_sim * 100, 2),
                "directional_ratio": round(dir_sim * 100, 2) if use_direction else None
            },
            "direction_compared": use_direction
        }

    def match(self, unknown_fingerprint: Dict[str, Any], min_confidence_threshold: float = 40.0) -> Dict[str, Any]:
        """
        Matches an unknown fingerprint against all reference fingerprints.
        Returns top 3 candidate labels, score breakdowns, and diagnostic notices.
        """
        if not self.references:
            return {
                "status": "EMPTY_DATASET",
                "message": "Reference fingerprint dataset is empty. Please import or synthesize reference captures first.",
                "candidates": [],
                "top_match": None,
                "is_conclusive": False
            }

        # Compare unknown against each reference sample
        label_scores: Dict[str, List[Dict[str, Any]]] = {}

        for ref in self.references:
            ref_label = ref.get("label", "Unknown")
            ref_vec = ref.get("feature_vector", {})
            comparison = self.compare_pair(unknown_fingerprint, ref_vec)
            
            if ref_label not in label_scores:
                label_scores[ref_label] = []

            label_scores[ref_label].append({
                "capture_id": ref.get("capture_id"),
                "original_name": ref.get("original_name", "capture"),
                "score": comparison["overall_similarity"],
                "components": comparison["components"],
                "ref_features": ref_vec
            })

        # Aggregate scores per website label
        aggregated_candidates: List[Dict[str, Any]] = []

        for label, samples in label_scores.items():
            scores = [s["score"] for s in samples]
            avg_score = round(float(np.mean(scores)), 2)
            max_score = round(float(np.max(scores)), 2)
            score_std = round(float(np.std(scores)), 2) if len(scores) > 1 else 0.0

            # Find best individual sample match for component inspection
            best_sample = max(samples, key=lambda s: s["score"])

            aggregated_candidates.append({
                "label": label,
                "average_score": avg_score,
                "best_score": max_score,
                "score_std": score_std,
                "sample_count": len(samples),
                "best_components": best_sample["components"],
                "samples_evaluated": samples
            })

        # Sort candidates by best_score descending
        aggregated_candidates.sort(key=lambda c: (c["best_score"], c["average_score"]), reverse=True)
        top_candidates = aggregated_candidates[:3]

        # Determine conclusiveness
        top_match = top_candidates[0] if top_candidates else None
        is_conclusive = False
        inconclusive_reason = ""

        if len(self.references) < 2:
            is_conclusive = False
            inconclusive_reason = "Dataset contains too few reference samples to make a reliable determination."
        elif top_match and top_match["best_score"] < min_confidence_threshold:
            is_conclusive = False
            inconclusive_reason = f"Top similarity score ({top_match['best_score']}%) is below the confidence threshold ({min_confidence_threshold}%)."
        elif len(top_candidates) >= 2 and (top_candidates[0]["best_score"] - top_candidates[1]["best_score"] < 2.0) and top_match["best_score"] < 50.0:
            is_conclusive = False
            inconclusive_reason = "Top candidate scores are statistically ambiguous and within standard margin of error."
        else:
            is_conclusive = True

        return {
            "status": "SUCCESS" if is_conclusive else "INCONCLUSIVE",
            "is_conclusive": is_conclusive,
            "inconclusive_reason": inconclusive_reason,
            "top_match": top_match,
            "candidates": top_candidates,
            "total_references_compared": len(self.references),
            "disclaimer": "ACADEMIC NOTICE: Similarity scores represent statistical distance metrics on encrypted metadata. They are NOT calibrated Bayesian probabilities that the user visited this specific website."
        }
