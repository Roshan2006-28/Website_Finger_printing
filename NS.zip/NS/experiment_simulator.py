"""
Controlled Experiment Simulator Module for Website Fingerprinting Attack Simulator.
Simulates defensive mechanisms (packet padding, timing jitter) and network perturbations
(background traffic, packet loss, truncation) purely in metadata space without touching live networks.
"""

import copy
import random
from typing import Dict, Any, List, Tuple
import numpy as np
from fingerprint import FingerprintExtractor
from matcher import FingerprintMatcher

class ExperimentSimulator:
    """
    Simulates defensive techniques and environmental noise against encrypted traffic fingerprints.
    """

    def __init__(self, random_seed: int = 42):
        self.random_seed = random_seed
        np.random.seed(random_seed)
        random.seed(random_seed)

    def apply_timing_jitter(self, base_summary: Dict[str, Any], max_jitter_ms: float = 50.0) -> Dict[str, Any]:
        """
        Scenario 1: Simulates defensive timing obfuscation (e.g., Tor-like random delays or jitter).
        Adds randomized delay to inter-arrival times and spreads duration.
        """
        modified = copy.deepcopy(base_summary)
        jitter_sec = max_jitter_ms / 1000.0

        old_mean_iat = modified.get("mean_iat", 0.01)
        new_mean_iat = old_mean_iat + (jitter_sec * 0.5)
        new_std_iat = modified.get("std_iat", 0.01) + jitter_sec

        modified["mean_iat"] = round(new_mean_iat, 6)
        modified["median_iat"] = round(modified.get("median_iat", 0.01) + (jitter_sec * 0.4), 6)
        modified["std_iat"] = round(new_std_iat, 6)

        total_pkts = modified.get("total_packets", 1)
        added_duration = (total_pkts * jitter_sec * 0.5)
        new_duration = round(modified.get("duration", 1.0) + added_duration, 4)
        modified["duration"] = new_duration
        modified["packets_per_sec"] = round(total_pkts / max(0.001, new_duration), 2)
        modified["bytes_per_sec"] = round(modified.get("total_bytes", 0) / max(0.001, new_duration), 2)

        # Perturb temporal volume distribution slightly
        time_vol = modified.get("time_volume_bins", [0] * 10)
        smoothed = []
        for i in range(len(time_vol)):
            left = time_vol[i - 1] if i > 0 else time_vol[i]
            right = time_vol[i + 1] if i < len(time_vol) - 1 else time_vol[i]
            smoothed.append(int(0.2 * left + 0.6 * time_vol[i] + 0.2 * right))
        modified["time_volume_bins"] = smoothed

        return modified

    def apply_background_traffic(self, base_summary: Dict[str, Any], noise_ratio: float = 0.35) -> Dict[str, Any]:
        """
        Scenario 2: Simulates realistic multi-tab browsing or background IoT/cloud sync traffic.
        Injects additional uncoordinated packets across varying sizes.
        """
        modified = copy.deepcopy(base_summary)
        orig_packets = modified.get("total_packets", 100)
        added_packets = int(orig_packets * noise_ratio)

        # Background packets: random mix of small ACKs (64-128B), DNS (80-200B), and assets (600-1400B)
        bg_sizes = [random.choice([64, 96, 128, 250, 520, 840, 1200, 1420]) for _ in range(added_packets)]
        added_bytes = sum(bg_sizes)

        new_total_pkts = orig_packets + added_packets
        new_total_bytes = modified.get("total_bytes", 1000) + added_bytes

        modified["total_packets"] = new_total_pkts
        modified["total_bytes"] = new_total_bytes
        modified["mean_packet_len"] = round(new_total_bytes / new_total_pkts, 2)

        # Update histogram with noise packets
        hist = modified.get("size_histogram", [0] * 9)
        bin_edges = [0, 100, 250, 500, 750, 1000, 1250, 1400, 1500, 2000]
        bg_hist, _ = np.histogram(bg_sizes, bins=bin_edges)
        for i in range(len(hist)):
            hist[i] += int(bg_hist[i])
        modified["size_histogram"] = hist

        # Distribute added bytes across time bins
        time_vol = modified.get("time_volume_bins", [0] * 10)
        per_bin_added = added_bytes // len(time_vol)
        modified["time_volume_bins"] = [v + per_bin_added for v in time_vol]

        return modified

    def apply_packet_padding(self, base_summary: Dict[str, Any], pad_to_bytes: int = 1460) -> Dict[str, Any]:
        """
        Scenario 3: Simulates state-of-the-art packet padding defense (e.g. Tamaraw / BuFLO / constant MTU).
        All packets are padded to maximum standard MTU size, destroying size distribution leakage.
        """
        modified = copy.deepcopy(base_summary)
        orig_packets = modified.get("total_packets", 100)

        # Padded traffic: all packets become MTU size
        new_total_bytes = orig_packets * pad_to_bytes
        modified["total_bytes"] = new_total_bytes
        modified["mean_packet_len"] = float(pad_to_bytes)
        modified["median_packet_len"] = float(pad_to_bytes)
        modified["std_packet_len"] = 0.0
        modified["min_packet_len"] = pad_to_bytes
        modified["max_packet_len"] = pad_to_bytes

        # Size histogram collapsed: all counts move into the 1400-1500 bin (index 7)
        hist = [0] * 9
        hist[7] = orig_packets
        modified["size_histogram"] = hist

        # Time bins scale proportionally to packet counts per bin
        dur = modified.get("duration", 1.0)
        modified["bytes_per_sec"] = round(new_total_bytes / max(0.001, dur), 2)

        return modified

    def apply_capture_truncation(self, base_summary: Dict[str, Any], keep_fraction: float = 0.40) -> Dict[str, Any]:
        """
        Scenario 4: Simulates an observer who only witnessed an incomplete portion of the session
        (e.g., user navigated away quickly, or packet sniffer started late).
        """
        modified = copy.deepcopy(base_summary)
        fraction = max(0.1, min(0.9, keep_fraction))

        orig_pkts = modified.get("total_packets", 100)
        orig_bytes = modified.get("total_bytes", 1000)
        orig_dur = modified.get("duration", 1.0)

        new_pkts = max(5, int(orig_pkts * fraction))
        new_bytes = max(500, int(orig_bytes * fraction))
        new_dur = round(orig_dur * fraction, 4)

        modified["total_packets"] = new_pkts
        modified["total_bytes"] = new_bytes
        modified["duration"] = new_dur

        # Scale histogram counts
        hist = modified.get("size_histogram", [0] * 9)
        modified["size_histogram"] = [int(c * fraction) for c in hist]

        # Truncate time bins (only the first N bins have traffic)
        active_bins = max(1, int(10 * fraction))
        time_vol = modified.get("time_volume_bins", [0] * 10)
        truncated_bins = time_vol[:active_bins] + [0] * (10 - active_bins)
        modified["time_volume_bins"] = truncated_bins

        return modified

    def apply_packet_loss(self, base_summary: Dict[str, Any], loss_rate: float = 0.20) -> Dict[str, Any]:
        """
        Scenario 5: Simulates a lossy network or imperfect packet collection by an observer.
        Drops packets at random, affecting volume and IAT dispersion.
        """
        modified = copy.deepcopy(base_summary)
        kept_ratio = 1.0 - max(0.01, min(0.5, loss_rate))

        orig_pkts = modified.get("total_packets", 100)
        orig_bytes = modified.get("total_bytes", 1000)

        new_pkts = max(5, int(orig_pkts * kept_ratio))
        new_bytes = max(500, int(orig_bytes * kept_ratio))

        modified["total_packets"] = new_pkts
        modified["total_bytes"] = new_bytes

        # IAT expands because missing packets leave temporal gaps
        modified["mean_iat"] = round(modified.get("mean_iat", 0.01) * (1.0 / kept_ratio), 6)
        modified["std_iat"] = round(modified.get("std_iat", 0.01) * 1.3, 6)

        hist = modified.get("size_histogram", [0] * 9)
        modified["size_histogram"] = [int(c * kept_ratio) for c in hist]

        time_vol = modified.get("time_volume_bins", [0] * 10)
        modified["time_volume_bins"] = [int(v * kept_ratio) for v in time_vol]

        return modified

    def run_experiment(
        self,
        scenario_id: str,
        baseline_summary: Dict[str, Any],
        reference_fingerprints: List[Dict[str, Any]],
        scenario_params: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Runs a complete end-to-end experiment comparing baseline match with defense/perturbation match.
        """
        # 1. Baseline feature extraction and matching
        baseline_vector = FingerprintExtractor.extract_feature_vector(baseline_summary)
        matcher = FingerprintMatcher(reference_fingerprints)
        baseline_match = matcher.match(baseline_vector)
        baseline_top = baseline_match.get("top_match")
        baseline_score = baseline_top["best_score"] if baseline_top else 0.0
        baseline_label = baseline_top["label"] if baseline_top else "None"

        # 2. Apply scenario transformation
        if scenario_id == "timing_jitter":
            max_jitter = float(scenario_params.get("max_jitter_ms", 50.0))
            modified_summary = self.apply_timing_jitter(baseline_summary, max_jitter)
            scenario_name = f"Timing Jitter (+/-{max_jitter}ms)"
            interpretation = "Timing jitter degraded timing and rate similarity, making inter-arrival patterns less identifiable."
        elif scenario_id == "background_traffic":
            noise_ratio = float(scenario_params.get("noise_ratio", 0.35))
            modified_summary = self.apply_background_traffic(baseline_summary, noise_ratio)
            scenario_name = f"Background Traffic (+{int(noise_ratio * 100)}% noise)"
            interpretation = "Ambient packets diluted the characteristic packet size histogram and distorted total volume statistics."
        elif scenario_id == "packet_padding":
            pad_size = int(scenario_params.get("pad_to_bytes", 1460))
            modified_summary = self.apply_packet_padding(baseline_summary, pad_size)
            scenario_name = f"Fixed Packet Padding ({pad_size}B MTU)"
            interpretation = "Padding normalized all packet lengths to constant MTU, neutralizing packet size distribution leakage entirely."
        elif scenario_id == "capture_truncation":
            keep_pct = float(scenario_params.get("keep_fraction", 0.40))
            modified_summary = self.apply_capture_truncation(baseline_summary, keep_pct)
            scenario_name = f"Capture Truncation (Kept {int(keep_pct * 100)}%)"
            interpretation = "Partial capture caused severe volume and temporal mismatch, demonstrating observer vulnerability to session cutoffs."
        elif scenario_id == "packet_loss":
            loss_pct = float(scenario_params.get("loss_rate", 0.20))
            modified_summary = self.apply_packet_loss(baseline_summary, loss_pct)
            scenario_name = f"Random Packet Loss ({int(loss_pct * 100)}% drop)"
            interpretation = "Packet loss increased apparent inter-arrival times and reduced byte volume, lowering statistical confidence."
        else:
            raise ValueError(f"Unknown scenario ID: {scenario_id}")

        # 3. Modified feature extraction and matching
        modified_vector = FingerprintExtractor.extract_feature_vector(modified_summary)
        modified_match = matcher.match(modified_vector)
        modified_top = modified_match.get("top_match")
        modified_score = modified_top["best_score"] if modified_top else 0.0
        modified_label = modified_top["label"] if modified_top else "None"

        # 4. Comparative Metrics
        score_delta = round(modified_score - baseline_score, 2)
        packet_delta = modified_summary.get("total_packets", 0) - baseline_summary.get("total_packets", 0)
        byte_delta = modified_summary.get("total_bytes", 0) - baseline_summary.get("total_bytes", 0)
        duration_delta = round(modified_summary.get("duration", 0.0) - baseline_summary.get("duration", 0.0), 4)

        return {
            "scenario_id": scenario_id,
            "scenario_name": scenario_name,
            "baseline_score": baseline_score,
            "baseline_label": baseline_label,
            "modified_score": modified_score,
            "modified_label": modified_label,
            "score_delta": score_delta,
            "packet_delta": packet_delta,
            "byte_delta": byte_delta,
            "duration_delta": duration_delta,
            "interpretation": interpretation,
            "baseline_summary": baseline_summary,
            "modified_summary": modified_summary,
            "baseline_match": baseline_match,
            "modified_match": modified_match
        }
