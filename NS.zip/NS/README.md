# Website Fingerprinting Attack Simulator: Analyzing Privacy Leakage in Encrypted Network Traffic

An academic, beginner-friendly cybersecurity research framework and web dashboard designed to simulate and evaluate **Website Fingerprinting (WF)** attacks and defenses on encrypted transport streams (HTTPS/TLS) using deterministic statistical distance matching.

---

## 1. Project Overview & Abstract

### 1.1 Problem Statement
Modern network protocols rely on cryptographic suites (such as TLS 1.2 and TLS 1.3 in HTTPS) to protect the confidentiality and integrity of communications. However, encryption standardizes payloads while leaving **transport and link-layer metadata visible in cleartext** to local and on-path observers (e.g., malicious Wi-Fi hotspots, ISP network taps, autonomous surveillance sensors). This metadata includes:
- Individual packet wire lengths.
- Direction of packet movement (client-to-server vs. server-to-client).
- Inter-arrival times (packet transmission intervals).
- Temporal burst patterns and aggregated traffic volumes.

### 1.2 Abstract
The **Website Fingerprinting Attack Simulator** demonstrates how an observer can passively infer destination identity by analyzing observable packet characteristics without decrypting cryptographic envelopes, intercepting keys, or inspecting application payloads. Built specifically for academic research and college cybersecurity curricula, the project avoids opaque "black-box" machine learning, employing instead a **transparent, multi-channel statistical distance matching engine**. The simulator also includes a **Controlled Defense Lab** that demonstrates how privacy-enhancing techniques—such as packet padding (BuFLO / Tamaraw), timing jitter, and dummy background cover traffic—measurably diminish fingerprint accuracy.

### 1.3 Key Objectives
1. **Passive Metadata Extraction:** Parse PCAP/PCAPNG files with Scapy without inspecting application contents.
2. **Deterministic Fingerprinting:** Generate standardized, normalized feature vectors across 6 orthogonal network dimensions.
3. **Transparent Matching:** Implement non-machine-learning statistical distance algorithms to rank candidate websites with similarity scores.
4. **Variability Demonstration:** Quantify and display variance across repeated visits to identical domains.
5. **Controlled Defense Evaluation:** Simulate defensive obfuscation in memory and measure score degradation.
6. **Academic Export:** Produce downloadable JSON dumps, CSV datasets, and formatted Markdown research reports.

---

## 2. System Architecture & Diagrams

### 2.1 System Architecture Diagram
```
+---------------------------------------------------------------------------------------+
|                                    USER INTERFACE                                     |
|           Dark Cybersecurity Web Dashboard (HTML5 / CSS3 / Vanilla JS / Chart.js)     |
+-------------------------------------------+-------------------------------------------+
                                            | HTTP REST API / Form Actions
+-------------------------------------------v-------------------------------------------+
|                                  FLASK CONTROLLER (app.py)                            |
|             Routing, Input Validation, Session Guardrails & Download Handlers         |
+---------+-------------------+--------------------+-------------------+----------------+
          |                   |                    |                   |
          v                   v                    v                   v
+-------------------+ +------------------+ +------------------+ +-----------------------+
|  PACKET ANALYZER  | |   FINGERPRINT    | |  MATCHING ENGINE | |  EXPERIMENT SIMULATOR |
| (packet_analyzer) | |   EXTRACTOR      | |   (matcher.py)   | |(experiment_simulator)|
| - Scapy Reader    | | (fingerprint.py) | | - L1 Histogram   | | - Constant MTU Padding|
| - Header lengths  | | - MTU Histogram  | |   Intersection   | | - Latency Jitter      |
| - Rel timestamps  | | - Temporal Decile| | - Cosine Sim     | | - Background Noise    |
| - Flow grouping   | | - Volume ratios  | | - Log-scale Vol  | | - Trace Truncation    |
| - IAT extraction  | | - Normalization  | | - Top-3 Ranking  | | - Random Packet Loss  |
+---------+---------+ +--------+---------+ +--------+---------+ +-----------+-----------+
          |                    |                    |                       |
          +--------------------+----------+---------+-----------------------+
                                          |
                                          v
+---------------------------------------------------------------------------------------+
|                                 SQLITE STORAGE (database.py)                          |
|         Tables: captures | fingerprints | analyses | experiments (Parameterized SQL)  |
+---------------------------------------------------------------------------------------+
```

### 2.2 Data Flow Diagram
```
[Authorized PCAP Trace / Synthetic Stream]
                   |
                   v
        [Module B: Packet Analyzer]
                   |--> Wire sizes, timestamps, IAT, directions, 5-tuples
                   v
      [Module C: Fingerprint Extractor]
                   |--> 21-element normalized statistical feature vector
                   v
      +------------+------------+
      |                         |
      v                         v
[Store in Database]   [Module D: Matching Engine] <--- [Reference Dataset]
                                |
                                v
               [L1 Intersection + Cosine + Timing]
                                |
                                v
                 Top 3 Ranked Candidates + Similarity Scores
                                |
                                v
              [Web Dashboard / Report Generator]
```

---

## 3. Technology Stack

- **Operating System:** Kali Linux 2024+, Ubuntu 22.04+, Debian 12+, or Windows 10/11
- **Programming Language:** Python 3.10+
- **Packet Dissection & Capture:** Scapy 2.5+
- **Numerical Computing:** NumPy 1.24+, Pandas 2.0+
- **Web Application Framework:** Flask 3.0+ & Werkzeug
- **Persistent Storage:** SQLite 3 (parameterized queries, zero external daemon)
- **Frontend Presentation:** HTML5, CSS3 (Dark Cybersecurity Theme), Vanilla JavaScript
- **Interactive Graphs:** Chart.js 4.4+ (Canvas-rendered, CDN-hosted)
- **Data Export Formats:** RFC 4180 CSV, JSON, and Academic Markdown

> **Strict Non-ML Policy:** TensorFlow, PyTorch, scikit-learn, external paid APIs, and cloud databases are intentionally excluded. All comparisons are mathematically transparent.

---

## 4. Installation & Setup on Kali Linux

Follow these commands in a Kali Linux or Ubuntu terminal:

### Step 1: Clone or Navigate to Project Directory
```bash
cd /path/to/website-fingerprinting
```

### Step 2: Update System & Install Python Dependencies
```bash
sudo apt update
sudo apt install -y python3 python3-pip python3-venv libpcap-dev
```

### Step 3: Create & Activate Python Virtual Environment
```bash
python3 -m venv venv
source venv/bin/activate
```

### Step 4: Install Python Requirements
```bash
pip install --upgrade pip
pip install -r requirements.txt
```

### Step 5: Generate Sample Datasets & Seed Database
```bash
python generate_sample_data.py
```
*This command synthesizes realistic PCAP captures for 5 website archetypes (Wikipedia, YouTube, DuckDuckGo, GitHub, NewsPortal) and seeds the SQLite database with reference fingerprints.*

### Step 6: Launch the Web Application
```bash
python app.py
```
Open your browser and navigate to:
```
http://127.0.0.1:5000
```

---

## 5. Modules & Directory Structure

```
website-fingerprinting/
├── app.py                      # Flask application router and endpoints
├── config.py                   # Global configuration, paths, and security limits
├── database.py                 # SQLite database initialization and parameterized CRUD
├── packet_analyzer.py          # Scapy metadata extractor (lengths, timestamps, IAT)
├── fingerprint.py              # Canonical feature vector constructor and normalizer
├── matcher.py                  # Transparent non-ML statistical distance matching engine
├── experiment_simulator.py     # Controlled defense lab (padding, jitter, noise)
├── report_generator.py         # CSV, JSON, and Markdown academic report exporters
├── generate_sample_data.py     # Synthetic PCAP generator and database seeder
├── requirements.txt            # Python dependencies
├── README.md                   # Complete academic documentation
├── database/                   # SQLite database directory (fingerprints.db)
├── captures/                   # Stored PCAP traces
├── reports/                    # Generated export files
├── sample_data/                # Sample profile documentation
├── templates/                  # Jinja2 HTML templates
│   ├── base.html               # Master layout with navigation and flash alerts
│   ├── index.html              # System dashboard with live Chart.js graphs
│   ├── upload.html             # PCAP upload, synthesis, and live capture tabs
│   ├── analysis.html           # Deep-dive traffic metadata inspection
│   ├── dataset.html            # Reference dataset manager & repeat variance tool
│   ├── compare.html            # Fingerprint matching engine with top 3 ranking
│   ├── experiments.html        # Controlled Defense & Perturbation Lab
│   ├── reports.html            # Export and download hub
│   └── about.html              # Academic methodology, threat model, and ethics
├── static/
│   ├── css/
│   │   └── style.css           # Dark cybersecurity theme (navy, charcoal, cyan, teal)
│   └── js/
│       ├── dashboard.js        # Dashboard chart bindings
│       ├── analysis.js         # Traffic analysis visualization logic
│       ├── comparison.js       # Matching engine radar and score charts
│       └── experiments.js      # Defense slider and before/after comparisons
└── tests/                      # Automated unit test suite
    ├── test_packet_analyzer.py # PCAP reading, empty files, malformed inputs
    ├── test_fingerprint.py     # Feature extraction, determinism, short captures
    ├── test_matcher.py         # Statistical distances, identical/distinct vectors
    ├── test_experiment_simulator.py # Padding, jitter, truncation, loss
    └── test_database.py        # Schema, parameterized queries, cascade deletion
```

---

## 6. Algorithm & Pseudocode

### 6.1 Fingerprint Extraction Algorithm
```python
ALGORITHM: ExtractFeatureVector(CaptureSummary S)
INPUT: S containing packet lengths L[], timestamps T[], and directional stats D
OUTPUT: Normalized feature vector F

1.  N <- length(L)
    IF N == 0: RETURN ZeroVector()

2.  TotalBytes <- sum(L)
    Duration <- max(0.0001, T[last] - T[first])

3.  MeanLen <- mean(L), MedianLen <- median(L), StdLen <- std(L)
    MeanIAT <- mean(diff(T)), StdIAT <- std(diff(T))

4.  # Build normalized 9-bin packet length histogram
    BinEdges <- [0, 100, 250, 500, 750, 1000, 1250, 1400, 1500, 2000]
    HistCounts <- Histogram(L, BinEdges)
    NormHist <- HistCounts / sum(HistCounts)

5.  # Build normalized 10-decile temporal volume distribution
    BinWidth <- Duration / 10
    DecileVolumes <- Array(10, 0)
    FOR each (t, length) in (T, L):
        bin_idx <- min(9, floor(t / BinWidth))
        DecileVolumes[bin_idx] += length
    NormTimeVol <- DecileVolumes / sum(DecileVolumes)

6.  F <- {
        "total_packets": N, "total_bytes": TotalBytes, "duration": Duration,
        "mean_packet_len": MeanLen, "median_packet_len": MedianLen, "std_packet_len": StdLen,
        "mean_iat": MeanIAT, "std_iat": StdIAT, "packet_rate": N / Duration,
        "byte_rate": TotalBytes / Duration, "size_histogram": NormHist,
        "time_volume": NormTimeVol, "direction_ratio": D.outgoing / N IF D.known ELSE -1.0
    }
    RETURN F
```

### 6.2 Statistical Distance Matching Algorithm
```python
ALGORITHM: MatchFingerprint(Target F_u, ReferenceDataset R)
INPUT: Unknown feature vector F_u, list of labeled reference vectors R
OUTPUT: Ranked candidate list with similarity scores in [0, 100]

1.  IF length(R) == 0: RETURN { status: "EMPTY_DATASET", candidates: [] }

2.  FOR each reference sample F_r in R:
        # A. Histogram L1 Intersection Similarity
        L1_diff <- sum(|F_u.size_histogram[i] - F_r.size_histogram[i]|)
        Sim_Hist <- 1.0 - 0.5 * L1_diff

        # B. Temporal Volume Cosine Projection
        Sim_Time <- dot(F_u.time_volume, F_r.time_volume) / (norm(F_u.time_volume) * norm(F_r.time_volume))

        # C. Packet Sizing Relative Distance
        Sim_Mean <- 1.0 - (|F_u.mean_len - F_r.mean_len| / max(F_u.mean_len, F_r.mean_len))
        Sim_Std  <- 1.0 - (|F_u.std_len - F_r.std_len| / max(F_u.std_len, F_r.std_len))
        Sim_SizeStats <- (Sim_Mean + Sim_Std) / 2.0

        # D. Log-Scaled Volume Distance
        Sim_Vol <- 1.0 - (|log10(F_u.total_bytes) - log10(F_r.total_bytes)| / max(log10(F_u.total_bytes), log10(F_r.total_bytes)))

        # E. Timing and Rate Distance
        Sim_IAT <- 1.0 - (|F_u.mean_iat - F_r.mean_iat| / max(F_u.mean_iat, F_r.mean_iat))

        # Weighted Aggregation
        Score <- (0.28 * Sim_Hist) + (0.22 * Sim_Time) + (0.22 * Sim_SizeStats) + (0.17 * Sim_Vol) + (0.11 * Sim_IAT)
        OverallPercent <- round(clamp(Score * 100.0, 0.0, 100.0), 2)
        RecordScore(F_r.label, OverallPercent)

3.  Group scores by label; compute BestScore, AvgScore, and StdDeviation for each label.
4.  Sort labels descending by BestScore.
5.  RETURN Top 3 Candidates
```

---

## 7. Automated Testing Suite

The project includes 25 unit tests covering edge cases, corrupted PCAPs, missing metadata, empty datasets, and mathematical accuracy.

To run the automated tests:
```bash
python -m unittest discover tests -v
```

### Verified Test Suite Results
| Module Tested | Test Case Description | Result |
|---|---|---|
| `test_packet_analyzer.py` | Empty 0-byte PCAP file handled gracefully | PASS |
| `test_packet_analyzer.py` | Corrupted binary file / invalid magic header rejected | PASS |
| `test_packet_analyzer.py` | Non-existent file returns informative dictionary | PASS |
| `test_packet_analyzer.py` | Single-packet capture duration & rates extracted safely | PASS |
| `test_packet_analyzer.py` | Valid synthetic packet trace parsed correctly | PASS |
| `test_packet_analyzer.py` | Missing directional metadata flagged as unknown | PASS |
| `test_packet_analyzer.py` | Private IPv4 address classification verified | PASS |
| `test_fingerprint.py` | Feature vector completeness (all 21 keys present) | PASS |
| `test_fingerprint.py` | Empty summary defaults prevent division-by-zero | PASS |
| `test_fingerprint.py` | Feature extraction determinism across identical inputs | PASS |
| `test_matcher.py` | Identical fingerprint comparison yields 100% similarity | PASS |
| `test_matcher.py` | Dissimilar fingerprints produce low similarity (<75%) | PASS |
| `test_matcher.py` | Empty reference dataset returns `EMPTY_DATASET` notice | PASS |
| `test_matcher.py` | Candidate ranking selects true origin as #1 candidate | PASS |
| `test_matcher.py` | Relative similarity math handles 0/0 and edge boundaries | PASS |
| `test_matcher.py` | L1 histogram intersection metric verified | PASS |
| `test_experiment_simulator.py`| Timing jitter increases session duration & IAT | PASS |
| `test_experiment_simulator.py`| Background traffic injects noise & alters histogram | PASS |
| `test_experiment_simulator.py`| Constant MTU padding normalizes sizes to single bin | PASS |
| `test_experiment_simulator.py`| Capture truncation reduces packets & duration | PASS |
| `test_experiment_simulator.py`| Random packet loss reduces volume & expands IAT | PASS |
| `test_database.py` | Database initialization and schema creation | PASS |
| `test_database.py` | Capture insertion and retrieval | PASS |
| `test_database.py` | SQL injection resilience via parameterized queries | PASS |
| `test_database.py` | Foreign key cascade deletion of fingerprints | PASS |

---

## 8. Practical Limitations of Website Fingerprinting

While website fingerprinting demonstrates significant statistical leakage in controlled laboratory settings, practical real-world deployments face substantial challenges:

1. **Browser Caching:** Repeat visits retrieve images, scripts, and stylesheets from the local disk cache, reducing packet count and altering burst sequences.
2. **Dynamic Web Content & Advertisements:** Personalization algorithms and third-party advertising auctions generate different assets on every page load.
3. **Content Delivery Networks (CDNs):** Major CDNs (Cloudflare, Akamai, Fastly) co-host thousands of domains across identical IP addresses and TLS termination points.
4. **Concurrent Multi-Tab Browsing:** Users rarely browse in single-tab isolation; background music streams, API syncs, and parallel tabs interleave packet sequences.
5. **Transport-Layer Obfuscation:** Technologies like QUIC (HTTP/3) and Encrypted Client Hello (ECH) obscure SNI, while Tor cell packing standardizes packets to 514-byte cells.

---

## 9. Ethical, Legal & Research Guidelines

> **IMPORTANT NOTICE:** This software is engineered strictly for academic education, defensive evaluation, and university laboratory research.

- **Authorized Monitoring Only:** Never capture network packets on networks, devices, or wireless environments without explicit written consent.
- **No Payload Inspection:** This tool is architected strictly to analyze link-layer metadata headers (packet wire length, direction, and timestamp). It intentionally avoids inspecting plaintext application payloads, HTTP cookies, passwords, or decrypted streams.
- **Defensive Focus:** The simulator's primary goal is to study how privacy-enhancing technologies (cell padding, traffic morphing, cover noise) neutralize passive eavesdropping.

---

## 10. College Project Demonstration Script (Step-by-Step for Faculty)

Follow this demonstration guide during your presentation:

1. **Introduce the Concept (2 min):**
   - Open the web dashboard (`http://127.0.0.1:5000`).
   - Explain the research problem: *"Even though HTTPS encrypts all web traffic, an observer on the local Wi-Fi can still see packet sizes and timing. Can this metadata reveal what website you are visiting?"*
   - Show the **Dashboard** metrics (Stored Captures, Reference Labels, Recent Analyses).

2. **Inspect Traffic Metadata (3 min):**
   - Click **Dashboard &rarr; Recent Traffic Captures &rarr; Inspect** on `ref_youtube_run1.pcap`.
   - Highlight the **Packet Size Distribution Histogram**: show how YouTube is dominated by large 1400–1500 byte incoming video frames.
   - Contrast this with `ref_wikipedia_run1.pcap` or `ref_duckduckgo_run1.pcap`, which exhibit much smaller, uniform packet distributions.

3. **Demonstrate Repeated Capture Variance (2 min):**
   - Navigate to **Fingerprint Dataset &rarr; Repeated Capture Variability Analyzer**.
   - Select `Wikipedia` and click **Analyze Repeats**.
   - Point out that Run #1 and Run #2 have slight differences in packet count and duration, explaining that real-world network traffic always contains natural jitter.

4. **Execute the Matching Engine (3 min):**
   - Navigate to **Matching Engine**.
   - Select `#22 - Unknown HTTPS Session (Evaluation Sample)`.
   - Click **Run Statistical Match**.
   - Show the result: The engine correctly identifies **Wikipedia** as the #1 candidate with high statistical similarity (>90%), while YouTube and DuckDuckGo score significantly lower.
   - Show the **Radar Chart** and explain the component contributions (Packet Sizing, Temporal Profile, Volume).
   - Point to the **Academic Disclaimer**: emphasize that this is a statistical similarity score, not a guaranteed probability.

5. **Demonstrate Privacy Defenses in the Defense Lab (3 min):**
   - Navigate to **Defense Lab**.
   - Select a baseline capture and choose **Packet Padding (Fixed MTU Defense - BuFLO/Tamaraw)**.
   - Click **Execute Controlled Simulation**.
   - Show the **Before vs After Histogram**: all packet lengths have collapsed into a single 1460-byte bin.
   - Show the **Score Delta**: similarity drops sharply, proving that packet padding successfully defeats website fingerprinting.

6. **Export Academic Reports (1 min):**
   - Navigate to **Reports**.
   - Click **Download Full Dataset CSV** and **Academic Report (.md)** to show downloadable deliverables.

---

## 11. Presentation Slide Outline

- **Slide 1: Title Slide**  
  *Website Fingerprinting Attack Simulator: Analyzing Privacy Leakage in Encrypted Network Traffic.*
- **Slide 2: The Core Problem**  
  *Encryption protects content, not metadata. Packet lengths, timing, and directions remain visible.*
- **Slide 3: Threat Model**  
  *Passive local observer (Wi-Fi eavesdropper, malicious ISP) monitoring encrypted traffic.*
- **Slide 4: Feature Engineering**  
  *The 6 observable metadata channels: Packet sizes, IAT, burst deciles, volume, throughput, direction.*
- **Slide 5: System Architecture**  
  *Modular design: Scapy Metadata Extractor, Normalizer, Statistical Matcher, SQLite, Flask UI.*
- **Slide 6: Non-ML Matching Methodology**  
  *Why avoid black-box ML? Using L1 Histogram Intersection and Cosine Temporal Alignment for transparent explainability.*
- **Slide 7: Experimental Results & Candidate Matching**  
  *Accurate differentiation between distinct website profiles (Wikipedia, YouTube, DuckDuckGo).*
- **Slide 8: Controlled Privacy Defenses**  
  *Evaluation of Fixed MTU Padding, Timing Jitter, and Ambient Noise.*
- **Slide 9: Real-World Limitations & Ethical Standards**  
  *Browser caching, multi-tab browsing, CDNs, and academic lab boundaries.*
- **Slide 10: Conclusion & Future Enhancements**  
  *Summary of findings, QUIC/HTTP3 analysis, and automated defensive traffic shaping.*
