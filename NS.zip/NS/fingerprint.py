"""
Fingerprint Feature Extractor Module for Website Fingerprinting Attack Simulator.
Constructs deterministic, normalized feature vectors from packet metadata.
Contains explicit handling for short captures, unknown directions, and scale normalization.
"""

from typing import Dict, Any, List
import numpy as np

# Feature weights used for statistical distance calculation
FEATURE_WEIGHTS = {
    "size_histogram": 0.25,       # Packet size distribution shape
    "time_volume_distribution": 0.20, # Temporal traffic burst pattern
    "packet_size_stats": 0.20,   # Mean, median, std packet sizes
    "traffic_volume_stats": 0.15,# Total packets and total bytes
    "timing_stats": 0.10,        # Duration and Inter-Arrival Times
    "direction_ratio": 0.10      # In/Out packet ratio if available
}

class FingerprintExtractor:
    """
    Extracts structured, deterministic statistical fingerprints from packet metadata summaries.
    """

    @staticmethod
    def extract_feature_vector(summary: Dict[str, Any]) -> Dict[str, Any]:
        """
        Builds a canonical, JSON-serializable feature vector from an analysis summary.
        """
        # Defensive defaults in case summary is incomplete or short capture
        total_packets = summary.get("total_packets", 0)
        total_bytes = summary.get("total_bytes", 0)
        duration = max(0.0001, summary.get("duration", 0.0001))

        # Size metrics
        mean_len = float(summary.get("mean_packet_len", 0.0))
        median_len = float(summary.get("median_packet_len", 0.0))
        std_len = float(summary.get("std_packet_len", 0.0))
        min_len = int(summary.get("min_packet_len", 0))
        max_len = int(summary.get("max_packet_len", 0))

        # Timing metrics
        mean_iat = float(summary.get("mean_iat", 0.0))
        median_iat = float(summary.get("median_iat", 0.0))
        std_iat = float(summary.get("std_iat", 0.0))
        packet_rate = float(summary.get("packets_per_sec", 0.0))
        byte_rate = float(summary.get("bytes_per_sec", 0.0))

        # Directional metrics
        directional = summary.get("directional", {})
        has_dir = directional.get("has_direction_knowledge", False)
        incoming_packets = directional.get("incoming_packets", 0)
        outgoing_packets = directional.get("outgoing_packets", 0)
        incoming_bytes = directional.get("incoming_bytes", 0)
        outgoing_bytes = directional.get("outgoing_bytes", 0)
        direction_ratio = directional.get("direction_ratio", -1.0)

        # Histogram Normalization (Shape of size distribution, sum = 1.0)
        raw_hist = summary.get("size_histogram", [0] * 9)
        hist_sum = sum(raw_hist)
        norm_hist = [round(c / hist_sum, 6) if hist_sum > 0 else 0.0 for c in raw_hist]

        # Time-binned volume normalization (Temporal profile, sum = 1.0)
        raw_time_vol = summary.get("time_volume_bins", [0] * 10)
        vol_sum = sum(raw_time_vol)
        norm_time_vol = [round(v / vol_sum, 6) if vol_sum > 0 else 0.0 for v in raw_time_vol]

        feature_vector = {
            "total_packets": total_packets,
            "total_bytes": total_bytes,
            "duration": round(duration, 4),
            "mean_packet_len": round(mean_len, 2),
            "median_packet_len": round(median_len, 2),
            "std_packet_len": round(std_len, 2),
            "min_packet_len": min_len,
            "max_packet_len": max_len,
            "mean_iat": round(mean_iat, 6),
            "median_iat": round(median_iat, 6),
            "std_iat": round(std_iat, 6),
            "packet_rate": round(packet_rate, 2),
            "byte_rate": round(byte_rate, 2),
            "has_direction_knowledge": has_dir,
            "incoming_packets": incoming_packets,
            "outgoing_packets": outgoing_packets,
            "incoming_bytes": incoming_bytes,
            "outgoing_bytes": outgoing_bytes,
            "direction_ratio": round(direction_ratio, 4) if has_dir else -1.0,
            "size_histogram_normalized": norm_hist,
            "time_volume_normalized": norm_time_vol
        }

        return feature_vector

    @staticmethod
    def get_feature_documentation() -> List[Dict[str, str]]:
        """
        Returns pedagogical documentation for each feature in the fingerprint vector.
        """
        return [
            {
                "feature": "size_histogram_normalized",
                "category": "Packet Sizing",
                "description": "Normalized distribution of packet lengths across 9 standard network MTU ranges.",
                "leakage_mechanism": "HTML files, stylesheets, and thumbnails produce characteristic packet sizes despite TLS encryption."
            },
            {
                "feature": "time_volume_normalized",
                "category": "Temporal Profile",
                "description": "Normalized fraction of total transferred bytes across 10 deciles of the session duration.",
                "leakage_mechanism": "Website asset loading sequence (DNS -> HTML -> CSS/JS -> Heavy images) creates distinct temporal traffic bursts."
            },
            {
                "feature": "total_bytes & total_packets",
                "category": "Traffic Volume",
                "description": "Aggregated size and count of all observed encrypted packets.",
                "leakage_mechanism": "Heavy media sites transfer tens of megabytes; lightweight search portals transfer under 200 KB."
            },
            {
                "feature": "mean_iat & std_iat",
                "category": "Timing",
                "description": "Average and dispersion of packet inter-arrival times.",
                "leakage_mechanism": "Server response times and TCP congestion pacing leave measurable timing footprints."
            },
            {
                "feature": "direction_ratio",
                "category": "Directionality",
                "description": "Ratio of outgoing requests to total packet transfers (when client endpoint is observable).",
                "leakage_mechanism": "Interactive or search websites issue more client requests than unidirectional streaming platforms."
            }
        ]
