"""
Configuration Settings for Website Fingerprinting Attack Simulator.
"""

import os
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"
os.environ["OMP_NUM_THREADS"] = "1"

from pathlib import Path

# Base Directory
BASE_DIR = Path(__file__).resolve().parent

# Application Security and Environment
SECRET_KEY = os.environ.get("FLASK_SECRET_KEY", "wf-simulator-academic-secret-key-2026")
HOST = "127.0.0.1"  # Bound strictly to localhost for academic security
PORT = 5000
DEBUG = True

# Storage Paths
DATABASE_PATH = os.path.join(BASE_DIR, "database", "fingerprints.db")
CAPTURES_DIR = os.path.join(BASE_DIR, "captures")
REPORTS_DIR = os.path.join(BASE_DIR, "reports")
SAMPLE_DATA_DIR = os.path.join(BASE_DIR, "sample_data")

# Upload Limits & Rules
MAX_CONTENT_LENGTH = 32 * 1024 * 1024  # 32 MB max upload
ALLOWED_EXTENSIONS = {"pcap", "pcapng", "cap"}

# Feature Extraction Settings
HISTOGRAM_BINS = [0, 100, 250, 500, 750, 1000, 1250, 1400, 1500, 2000]
TIME_VOLUME_BINS = 10  # 10 decile bins for capture duration

# Live Capture (Optional - Disabled by default)
LIVE_CAPTURE_ENABLED = True
MAX_LIVE_CAPTURE_DURATION = 30  # Max 30 seconds for lab safety
DEFAULT_CAPTURE_INTERFACE = "eth0"  # Or 'Ethernet' on Windows
