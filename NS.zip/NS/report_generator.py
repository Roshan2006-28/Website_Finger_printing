"""
Report Generator Module for Website Fingerprinting Attack Simulator.
Generates CSV summaries, JSON structured dumps, and comprehensive academic Markdown reports.
Payload-agnostic and privacy-preserving.
"""

import os
import json
import csv
import io
from datetime import datetime
from typing import Dict, Any, List, Optional
from config import REPORTS_DIR

class ReportGenerator:
    """
    Handles export and formatting of traffic metadata, fingerprint comparisons,
    and academic evaluation summaries.
    """

    @staticmethod
    def generate_csv_summary(captures: List[Dict[str, Any]]) -> str:
        """
        Exports a collection of capture summaries into a standard CSV format.
        """
        output = io.StringIO()
        fieldnames = [
            "id", "original_name", "label", "packet_count", "file_size_bytes",
            "duration", "is_reference", "is_synthetic", "created_at"
        ]
        writer = csv.DictWriter(output, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()

        for cap in captures:
            writer.writerow(cap)

        return output.getvalue()

    @staticmethod
    def generate_json_export(
        capture: Dict[str, Any],
        fingerprint: Dict[str, Any],
        match_result: Optional[Dict[str, Any]] = None
    ) -> str:
        """
        Exports capture metadata, full feature vector, and matching result as structured JSON.
        """
        export_data = {
            "academic_context": {
                "project": "Website Fingerprinting Attack Simulator",
                "framework": "Statistical Metadata Analysis (Non-Machine Learning)",
                "generated_at": datetime.now().isoformat(),
                "confidentiality_notice": "Contains only encrypted traffic metadata (lengths, timing, directions). No decrypted payloads."
            },
            "capture_metadata": {
                "id": capture.get("id"),
                "original_filename": capture.get("original_name"),
                "assigned_label": capture.get("label"),
                "total_packets": capture.get("packet_count"),
                "file_size_bytes": capture.get("file_size_bytes"),
                "duration_seconds": capture.get("duration"),
                "is_reference": bool(capture.get("is_reference")),
                "is_synthetic": bool(capture.get("is_synthetic"))
            },
            "fingerprint_feature_vector": fingerprint.get("feature_vector", {}),
            "matching_evaluation": match_result or {
                "status": "NOT_EVALUATED"
            }
        }
        return json.dumps(export_data, indent=2)

    @staticmethod
    def generate_markdown_report(
        capture: Dict[str, Any],
        fingerprint: Dict[str, Any],
        match_result: Optional[Dict[str, Any]] = None
    ) -> str:
        """
        Generates a comprehensive academic research report in Markdown.
        """
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        f_vec = fingerprint.get("feature_vector", {})
        summary = fingerprint.get("summary", {})

        top_match = match_result.get("top_match") if match_result else None
        top_label = top_match["label"] if top_match else "N/A"
        top_score = top_match["best_score"] if top_match else 0.0

        md = f"""# Academic Research Report: Encrypted Traffic Fingerprint Analysis
**Project:** Website Fingerprinting Attack Simulator  
**Generated:** {timestamp}  
**Classification:** Academic Lab Evaluation  

---

## 1. Executive Summary
This report documents the statistical metadata analysis of an encrypted network session (HTTPS/TLS).
Website fingerprinting observes passive physical and link-layer metadata—specifically packet lengths,
burst volumes, and inter-arrival intervals—to infer destination identity without cryptographic inspection.

- **Sample Identifier:** #{capture.get('id')} (`{capture.get('original_name')}`)
- **Assigned Website Label:** `{capture.get('label')}`
- **Evaluation Status:** {'Conclusive Match' if match_result and match_result.get('is_conclusive') else 'Inconclusive / Ambiguous'}
- **Inferred Candidate:** `{top_label}` (Statistical Similarity: **{top_score}%**)

---

## 2. Capture Metadata
| Attribute | Measured Value |
|---|---|
| Total Observed Packets | {capture.get('packet_count', 0):,} |
| Total Captured Volume | {capture.get('file_size_bytes', 0):,} bytes |
| Session Duration | {capture.get('duration', 0):.4f} seconds |
| Packet Transfer Rate | {summary.get('packets_per_sec', 0)} pkts/sec |
| Bandwidth Throughput | {summary.get('bytes_per_sec', 0):,} bytes/sec |
| Directional Observability | {'Yes (Client/Server Distinct)' if f_vec.get('has_direction_knowledge') else 'No (Direction Ambiguous)'} |

---

## 3. Extracted Fingerprint Features
### 3.1 Packet Size Statistics
- **Mean Packet Size:** {f_vec.get('mean_packet_len', 0)} bytes
- **Median Packet Size:** {f_vec.get('median_packet_len', 0)} bytes
- **Standard Deviation:** {f_vec.get('std_packet_len', 0)} bytes
- **Range:** [{f_vec.get('min_packet_len', 0)}B - {f_vec.get('max_packet_len', 0)}B]

### 3.2 Temporal & Timing Footprint
- **Mean Inter-Arrival Time (IAT):** {f_vec.get('mean_iat', 0)} sec
- **Median Inter-Arrival Time:** {f_vec.get('median_iat', 0)} sec
- **IAT Standard Deviation:** {f_vec.get('std_iat', 0)} sec

### 3.3 Directional Breakdown
- **Outgoing Packets:** {f_vec.get('outgoing_packets', 0):,} ({f_vec.get('outgoing_bytes', 0):,} bytes)
- **Incoming Packets:** {f_vec.get('incoming_packets', 0):,} ({f_vec.get('incoming_bytes', 0):,} bytes)
- **Out/Total Ratio:** {f_vec.get('direction_ratio', -1.0)}

---

## 4. Matching & Similarity Results
"""
        if match_result and match_result.get("candidates"):
            md += "\n| Rank | Candidate Label | Best Match | Avg Score | Variance (Std) | Samples Tested |\n"
            md += "|---|---|---|---|---|---|\n"
            for idx, cand in enumerate(match_result["candidates"], 1):
                md += f"| #{idx} | **{cand['label']}** | **{cand['best_score']}%** | {cand['average_score']}% | +/-{cand['score_std']} | {cand['sample_count']} |\n"

            if top_match and "best_components" in top_match:
                md += "\n### Component-Level Similarity Contribution\n"
                comps = top_match["best_components"]
                for comp, score in comps.items():
                    if score is not None:
                        md += f"- **{comp.replace('_', ' ').title()}:** {score}%\n"
        else:
            md += "\n*No reference candidates evaluated or dataset empty.*\n"

        md += """
---

## 5. Security & Privacy Notice
> **IMPORTANT NOTICE:** The similarity scores presented in this report represent non-machine-learning statistical
> distance calculations across encrypted transport-layer metadata. A high similarity score indicates structural
> similarity in packet length and burst distribution; **it is not a calibrated Bayesian probability** that the user
> accessed the target domain. Real-world accuracy degrades severely in the presence of browser caching, CDN co-hosting,
> background tab activity, and variable network paths.

---

## 6. Recommended Privacy Defenses
1. **Application-Layer Packet Padding:** Padded cells (e.g. padding all TLS records to fixed 1460-byte blocks) eliminates packet size histogram leakage.
2. **Defensive Traffic Morphing (BuFLO / Tamaraw):** Transmitting packets at deterministic, clock-governed intervals eliminates timing and inter-arrival leakage.
3. **Multi-Tab / Dummy Background Noise:** Ambient traffic injections significantly increase observer uncertainty and false positive rates.
"""
        return md
