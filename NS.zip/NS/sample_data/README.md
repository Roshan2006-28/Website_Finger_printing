# Sample Network Captures & Traffic Profiles

This directory contains reference and evaluation packet captures generated for the Website Fingerprinting Attack Simulator.

## 1. Website Traffic Archetypes

Each profile mimics observable link-layer transport metadata (packet sizes, burst distributions, and timing) without decrypting application payloads:

1. **Wikipedia**
   - **Characteristics:** Encyclopedic, text-heavy, moderate script size, uniform packet distribution.
   - **Packet Count:** ~180 - 260 packets.
   - **Observed Flow:** Initial HTTPS handshake & certificate exchange, burst of CSS/JS, steady text retrieval.

2. **YouTube**
   - **Characteristics:** Video streaming, high throughput, dominant incoming volume, large MTU packets.
   - **Packet Count:** ~500 - 750 packets.
   - **Observed Flow:** Small client TCP ACKs, dominated by 1420 - 1514 byte incoming media blocks.

3. **DuckDuckGo**
   - **Characteristics:** Lightweight search engine, rapid transactions, minimal payload.
   - **Packet Count:** ~45 - 75 packets.
   - **Observed Flow:** Compact client queries and instant JSON/HTML responses. Very short session duration (< 1.2s).

4. **GitHub**
   - **Characteristics:** Developer platform, code repositories, bidirectional API calls.
   - **Packet Count:** ~280 - 420 packets.
   - **Observed Flow:** Balanced bidirectional packet bursts, commit diff downloads, and icons.

5. **NewsPortal**
   - **Characteristics:** Bursty multi-CDN downloads, tracking scripts, ad network requests, image banners.
   - **Packet Count:** ~400 - 600 packets.
   - **Observed Flow:** Clustered concurrent bursts across multiple time deciles.

## 2. Generating or Re-seeding Captures

To regenerate the PCAP files and re-seed the SQLite database:

```bash
python generate_sample_data.py
```

All synthesized PCAP traces are saved in the `captures/` directory and cataloged in the SQLite database (`database/fingerprints.db`).
