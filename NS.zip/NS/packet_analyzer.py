"""
Packet Metadata Analyzer Module for Website Fingerprinting Attack Simulator.
Extracts wire metadata (sizes, timestamps, directions, inter-arrival times)
without decrypting HTTPS or inspecting application payloads.
"""

import os
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"

import math
from typing import Dict, Any, List, Optional, Tuple
import numpy as np

# Import Scapy components for offline PCAP reading
try:
    from scapy.all import rdpcap, PcapReader, IP, IPv6, TCP, UDP, ARP
    SCAPY_AVAILABLE = True
except ImportError:
    SCAPY_AVAILABLE = False


def is_private_ip(ip_str: str) -> bool:
    """Checks if an IPv4 address is in a private or loopback range."""
    if not ip_str:
        return False
    if ip_str.startswith("127.") or ip_str == "::1":
        return True
    if ip_str.startswith("10.") or ip_str.startswith("192.168."):
        return True
    if ip_str.startswith("172."):
        parts = ip_str.split(".")
        if len(parts) >= 2 and parts[1].isdigit():
            sec = int(parts[1])
            if 16 <= sec <= 31:
                return True
    return False


def infer_client_ip(packets) -> Optional[str]:
    """
    Infers the local client IP address from packet metadata.
    Prioritizes:
    1. TCP SYN packets (client initiating connection)
    2. Private IP addresses (192.168.x, 10.x, 172.16-31.x, 127.0.0.1)
    3. Most frequent endpoint in bidirectional traffic
    """
    ip_counts: Dict[str, int] = {}
    syn_sources: Dict[str, int] = {}

    for pkt in packets:
        src = None
        if IP in pkt:
            src = pkt[IP].src
        elif IPv6 in pkt:
            src = pkt[IPv6].src

        if src:
            ip_counts[src] = ip_counts.get(src, 0) + 1
            if TCP in pkt and (pkt[TCP].flags & 0x02) and not (pkt[TCP].flags & 0x10):
                # Pure SYN packet
                syn_sources[src] = syn_sources.get(src, 0) + 1

    # If SYN initiator found, it's overwhelmingly the client
    if syn_sources:
        return max(syn_sources.items(), key=lambda x: x[1])[0]

    # Otherwise look for private IP candidates
    private_candidates = [ip for ip in ip_counts.keys() if is_private_ip(ip)]
    if private_candidates:
        return max(private_candidates, key=lambda ip: ip_counts[ip])

    # If all public, pick the most frequent IP
    if ip_counts:
        return max(ip_counts.items(), key=lambda x: x[1])[0]

    return None


class PacketAnalyzer:
    """
    Analyzes packet capture files and extracts statistical network metadata.
    Ensures safe, payload-agnostic extraction.
    """

    def __init__(self, pcap_path: str, client_ip: Optional[str] = None):
        self.pcap_path = pcap_path
        self.client_ip = client_ip
        self.error_message: Optional[str] = None
        self.raw_packet_metadata: List[Dict[str, Any]] = []

    def analyze(self) -> Dict[str, Any]:
        """
        Reads the PCAP file and extracts all statistical traffic metadata.
        Returns a dictionary of metrics, distributions, and flow statistics.
        """
        if not SCAPY_AVAILABLE:
            return {"error": "Scapy library is not installed or available."}

        if not os.path.exists(self.pcap_path):
            return {"error": f"Capture file not found: {self.pcap_path}"}

        file_size = os.path.getsize(self.pcap_path)
        if file_size == 0:
            return {"error": "Capture file is empty (0 bytes)."}

        try:
            # Read packets using Scapy's rdpcap
            packets = rdpcap(self.pcap_path)
        except Exception as e:
            return {"error": f"Failed to parse PCAP file: {str(e)}"}

        total_packet_count = len(packets)
        if total_packet_count == 0:
            return {
                "error": "Capture contains 0 packets.",
                "total_packets": 0,
                "file_size_bytes": file_size
            }

        # Determine client IP for directionality if not specified
        client_ip = self.client_ip or infer_client_ip(packets)
        has_direction_knowledge = client_ip is not None

        timestamps: List[float] = []
        lengths: List[int] = []
        directions: List[int] = []  # +1 = Outgoing, -1 = Incoming, 0 = Unknown
        flows: Dict[str, Dict[str, Any]] = {}

        incoming_bytes = 0
        outgoing_bytes = 0
        unknown_bytes = 0

        incoming_packets = 0
        outgoing_packets = 0
        unknown_packets = 0

        first_timestamp = None

        for idx, pkt in enumerate(packets):
            # Packet timestamp extraction
            try:
                pkt_time = float(pkt.time)
            except (AttributeError, ValueError, TypeError):
                # Fallback if timestamp missing: synthesize relative 1ms interval
                pkt_time = (first_timestamp or 0.0) + (idx * 0.001)

            if first_timestamp is None:
                first_timestamp = pkt_time

            rel_time = round(pkt_time - first_timestamp, 6)
            timestamps.append(rel_time)

            # Packet wire length (metadata only, no payload inspection)
            length = len(pkt)
            lengths.append(length)

            # Direction inference (+1 Outgoing, -1 Incoming, 0 Unknown)
            direction = 0
            src_ip = None
            dst_ip = None
            proto_name = "OTHER"
            sport = None
            dport = None

            if IP in pkt:
                src_ip = pkt[IP].src
                dst_ip = pkt[IP].dst
            elif IPv6 in pkt:
                src_ip = pkt[IPv6].src
                dst_ip = pkt[IPv6].dst

            if TCP in pkt:
                proto_name = "TCP"
                sport = pkt[TCP].sport
                dport = pkt[TCP].dport
            elif UDP in pkt:
                proto_name = "UDP"
                sport = pkt[UDP].sport
                dport = pkt[UDP].dport
            elif ARP in pkt:
                proto_name = "ARP"

            if has_direction_knowledge and src_ip and dst_ip:
                if src_ip == client_ip:
                    direction = 1
                    outgoing_packets += 1
                    outgoing_bytes += length
                elif dst_ip == client_ip:
                    direction = -1
                    incoming_packets += 1
                    incoming_bytes += length
                else:
                    direction = 0
                    unknown_packets += 1
                    unknown_bytes += length
            else:
                direction = 0
                unknown_packets += 1
                unknown_bytes += length

            directions.append(direction)

            # Flow tracking (5-tuple without inspect payload)
            if src_ip and dst_ip and sport and dport:
                flow_key = f"{proto_name}:{min(src_ip, dst_ip)}:{max(src_ip, dst_ip)}:{min(sport, dport)}-{max(sport, dport)}"
                if flow_key not in flows:
                    flows[flow_key] = {
                        "protocol": proto_name,
                        "endpoint_a": f"{src_ip}:{sport}",
                        "endpoint_b": f"{dst_ip}:{dport}",
                        "packet_count": 0,
                        "byte_count": 0
                    }
                flows[flow_key]["packet_count"] += 1
                flows[flow_key]["byte_count"] += length

            # Store compact raw record for plotting (cap at 2000 points to keep UI snappy)
            if idx < 2000:
                self.raw_packet_metadata.append({
                    "index": idx,
                    "rel_time": rel_time,
                    "length": length,
                    "direction": direction
                })

        # Calculate Inter-Arrival Times (IAT)
        iats: List[float] = []
        for i in range(1, len(timestamps)):
            delta = max(0.0, timestamps[i] - timestamps[i - 1])
            iats.append(round(delta, 6))

        # Basic statistics using NumPy
        np_lengths = np.array(lengths)
        np_iats = np.array(iats) if iats else np.array([0.0])

        total_bytes = int(np.sum(np_lengths))
        duration = float(timestamps[-1] - timestamps[0]) if len(timestamps) > 1 else 0.0
        duration = max(0.0001, duration)  # Avoid division by zero

        mean_len = float(np.mean(np_lengths))
        median_len = float(np.median(np_lengths))
        std_len = float(np.std(np_lengths))
        min_len = int(np.min(np_lengths))
        max_len = int(np.max(np_lengths))

        mean_iat = float(np.mean(np_iats))
        median_iat = float(np.median(np_iats))
        std_iat = float(np.std(np_iats))

        bytes_per_sec = round(total_bytes / duration, 2)
        packets_per_sec = round(total_packet_count / duration, 2)

        # Fixed-bin packet size histogram
        bin_edges = [0, 100, 250, 500, 750, 1000, 1250, 1400, 1500, 2000]
        hist_counts, _ = np.histogram(np_lengths, bins=bin_edges)
        size_histogram = [int(c) for c in hist_counts]

        # Time-binned traffic volume (10 deciles of capture duration)
        num_time_bins = 10
        time_volume_bins = [0] * num_time_bins
        bin_width = duration / num_time_bins

        for t, l in zip(timestamps, lengths):
            bin_idx = min(num_time_bins - 1, int(t / bin_width)) if bin_width > 0 else 0
            time_volume_bins[bin_idx] += l

        # Directional statistics
        dir_breakdown = {
            "has_direction_knowledge": has_direction_knowledge,
            "inferred_client_ip": client_ip,
            "incoming_packets": incoming_packets,
            "outgoing_packets": outgoing_packets,
            "unknown_packets": unknown_packets,
            "incoming_bytes": incoming_bytes,
            "outgoing_bytes": outgoing_bytes,
            "unknown_bytes": unknown_bytes,
            "direction_ratio": round(outgoing_packets / total_packet_count, 4) if total_packet_count > 0 and has_direction_knowledge else -1.0
        }

        # Format flow summary (top 5 flows by byte volume)
        sorted_flows = sorted(flows.values(), key=lambda f: f["byte_count"], reverse=True)[:5]

        # Prepare summary dictionary
        summary = {
            "total_packets": total_packet_count,
            "total_bytes": total_bytes,
            "duration": round(duration, 4),
            "file_size_bytes": file_size,
            "mean_packet_len": round(mean_len, 2),
            "median_packet_len": round(median_len, 2),
            "std_packet_len": round(std_len, 2),
            "min_packet_len": min_len,
            "max_packet_len": max_len,
            "mean_iat": round(mean_iat, 6),
            "median_iat": round(median_iat, 6),
            "std_iat": round(std_iat, 6),
            "bytes_per_sec": bytes_per_sec,
            "packets_per_sec": packets_per_sec,
            "size_histogram": size_histogram,
            "time_volume_bins": time_volume_bins,
            "directional": dir_breakdown,
            "top_flows": sorted_flows,
            "sample_packets": self.raw_packet_metadata[:300]  # First 300 packets for detailed UI visualization
        }

        return summary
