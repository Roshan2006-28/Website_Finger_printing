"""
Database Management Module for Website Fingerprinting Attack Simulator.
Provides safe, parameterized SQLite operations for captures, fingerprints,
analyses, and defense experiments.
"""

import sqlite3
import json
import os
from datetime import datetime
from typing import Dict, Any, List, Optional
from werkzeug.security import generate_password_hash, check_password_hash
from config import DATABASE_PATH

def get_db_connection() -> sqlite3.Connection:
    """Creates a connection to the SQLite database with row factory and FK enabled."""
    os.makedirs(os.path.dirname(DATABASE_PATH), exist_ok=True)
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn

def init_db() -> None:
    """Initializes the database schema if tables do not already exist."""
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.executescript("""
    CREATE TABLE IF NOT EXISTS captures (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        filename TEXT NOT NULL UNIQUE,
        original_name TEXT NOT NULL,
        label TEXT NOT NULL,
        capture_time TEXT,
        packet_count INTEGER DEFAULT 0,
        file_size_bytes INTEGER DEFAULT 0,
        duration REAL DEFAULT 0.0,
        is_synthetic INTEGER DEFAULT 0,
        is_reference INTEGER DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS fingerprints (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        capture_id INTEGER NOT NULL UNIQUE,
        label TEXT NOT NULL,
        feature_vector_json TEXT NOT NULL,
        summary_json TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (capture_id) REFERENCES captures(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS analyses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        capture_id INTEGER NOT NULL,
        analysis_type TEXT DEFAULT 'statistical',
        results_json TEXT NOT NULL,
        top_match_label TEXT,
        similarity_score REAL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (capture_id) REFERENCES captures(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS experiments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        scenario_name TEXT NOT NULL,
        baseline_capture_id INTEGER NOT NULL,
        modified_capture_id INTEGER,
        baseline_score REAL,
        modified_score REAL,
        score_delta REAL,
        parameters_json TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (baseline_capture_id) REFERENCES captures(id) ON DELETE CASCADE,
        FOREIGN KEY (modified_capture_id) REFERENCES captures(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'user',
        full_name TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        last_login TIMESTAMP
    );
    """)

    conn.commit()
    conn.close()

    seed_default_users()

# ----------------- Captures CRUD -----------------

def insert_capture(
    filename: str,
    original_name: str,
    label: str,
    capture_time: Optional[str] = None,
    packet_count: int = 0,
    file_size_bytes: int = 0,
    duration: float = 0.0,
    is_synthetic: bool = False,
    is_reference: bool = False
) -> int:
    """Inserts a new capture entry into the database."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT OR REPLACE INTO captures (
            filename, original_name, label, capture_time,
            packet_count, file_size_bytes, duration, is_synthetic, is_reference
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        filename, original_name, label.strip(), capture_time,
        packet_count, file_size_bytes, duration,
        1 if is_synthetic else 0,
        1 if is_reference else 0
    ))
    capture_id = cursor.lastrowid
    conn.commit()
    conn.close()
    return capture_id

def get_capture(capture_id: int) -> Optional[Dict[str, Any]]:
    """Retrieves a single capture by ID."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM captures WHERE id = ?", (capture_id,))
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None

def list_captures(search_query: Optional[str] = None, reference_only: bool = False) -> List[Dict[str, Any]]:
    """Lists captures with optional search query and reference filtering."""
    conn = get_db_connection()
    cursor = conn.cursor()
    query = "SELECT * FROM captures WHERE 1=1"
    params: List[Any] = []

    if reference_only:
        query += " AND is_reference = 1"
    if search_query:
        query += " AND (label LIKE ? OR original_name LIKE ?)"
        wildcard = f"%{search_query.strip()}%"
        params.extend([wildcard, wildcard])

    query += " ORDER BY id DESC"
    cursor.execute(query, tuple(params))
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]

def delete_capture(capture_id: int) -> Optional[str]:
    """Deletes a capture and associated records. Returns filename if deleted."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT filename FROM captures WHERE id = ?", (capture_id,))
    row = cursor.fetchone()
    if not row:
        conn.close()
        return None
    
    filename = row["filename"]
    cursor.execute("DELETE FROM captures WHERE id = ?", (capture_id,))
    conn.commit()
    conn.close()
    return filename

# ----------------- Fingerprints CRUD -----------------

def store_fingerprint(
    capture_id: int,
    label: str,
    feature_vector: Dict[str, Any],
    summary: Dict[str, Any]
) -> int:
    """Stores a deterministic fingerprint feature vector for a capture."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT OR REPLACE INTO fingerprints (
            capture_id, label, feature_vector_json, summary_json
        ) VALUES (?, ?, ?, ?)
    """, (
        capture_id,
        label.strip(),
        json.dumps(feature_vector),
        json.dumps(summary)
    ))
    fp_id = cursor.lastrowid
    conn.commit()
    conn.close()
    return fp_id

def get_fingerprint_by_capture(capture_id: int) -> Optional[Dict[str, Any]]:
    """Retrieves the fingerprint associated with a specific capture."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM fingerprints WHERE capture_id = ?", (capture_id,))
    row = cursor.fetchone()
    conn.close()
    if row:
        data = dict(row)
        data["feature_vector"] = json.loads(data["feature_vector_json"])
        data["summary"] = json.loads(data["summary_json"])
        return data
    return None

def list_reference_fingerprints() -> List[Dict[str, Any]]:
    """Retrieves all fingerprints labeled as reference dataset items."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT f.*, c.original_name, c.packet_count, c.file_size_bytes, c.duration, c.is_synthetic
        FROM fingerprints f
        JOIN captures c ON f.capture_id = c.id
        WHERE c.is_reference = 1
        ORDER BY f.label ASC, f.id DESC
    """)
    rows = cursor.fetchall()
    conn.close()
    results = []
    for r in rows:
        d = dict(r)
        d["feature_vector"] = json.loads(d["feature_vector_json"])
        d["summary"] = json.loads(d["summary_json"])
        results.append(d)
    return results

def get_repeated_captures(label: str) -> List[Dict[str, Any]]:
    """Retrieves all captures and fingerprints for a given label to compare variability."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT f.*, c.original_name, c.packet_count, c.file_size_bytes, c.duration
        FROM fingerprints f
        JOIN captures c ON f.capture_id = c.id
        WHERE f.label = ?
        ORDER BY f.id ASC
    """, (label,))
    rows = cursor.fetchall()
    conn.close()
    results = []
    for r in rows:
        d = dict(r)
        d["feature_vector"] = json.loads(d["feature_vector_json"])
        d["summary"] = json.loads(d["summary_json"])
        results.append(d)
    return results

# ----------------- Analyses CRUD -----------------

def log_analysis(
    capture_id: int,
    results: Dict[str, Any],
    top_match_label: Optional[str],
    similarity_score: Optional[float]
) -> int:
    """Logs the results of a fingerprint matching run."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO analyses (
            capture_id, analysis_type, results_json, top_match_label, similarity_score
        ) VALUES (?, 'statistical', ?, ?, ?)
    """, (
        capture_id,
        json.dumps(results),
        top_match_label,
        similarity_score
    ))
    analysis_id = cursor.lastrowid
    conn.commit()
    conn.close()
    return analysis_id

def list_analyses(limit: int = 10) -> List[Dict[str, Any]]:
    """Lists recent analyses with related capture metadata."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT a.*, c.original_name, c.label AS true_label, c.packet_count
        FROM analyses a
        JOIN captures c ON a.capture_id = c.id
        ORDER BY a.id DESC
        LIMIT ?
    """, (limit,))
    rows = cursor.fetchall()
    conn.close()
    results = []
    for r in rows:
        d = dict(r)
        d["results"] = json.loads(d["results_json"])
        results.append(d)
    return results

# ----------------- Experiments CRUD -----------------

def log_experiment(
    scenario_name: str,
    baseline_capture_id: int,
    modified_capture_id: Optional[int],
    baseline_score: float,
    modified_score: float,
    score_delta: float,
    parameters: Dict[str, Any]
) -> int:
    """Logs an experimental scenario comparison."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO experiments (
            scenario_name, baseline_capture_id, modified_capture_id,
            baseline_score, modified_score, score_delta, parameters_json
        ) VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (
        scenario_name, baseline_capture_id, modified_capture_id,
        baseline_score, modified_score, score_delta,
        json.dumps(parameters)
    ))
    exp_id = cursor.lastrowid
    conn.commit()
    conn.close()
    return exp_id

def list_experiments(limit: int = 10) -> List[Dict[str, Any]]:
    """Lists recent experimental evaluations."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT e.*, c.original_name AS baseline_name, c.label AS baseline_label
        FROM experiments e
        JOIN captures c ON e.baseline_capture_id = c.id
        ORDER BY e.id DESC
        LIMIT ?
    """, (limit,))
    rows = cursor.fetchall()
    conn.close()
    results = []
    for r in rows:
        d = dict(r)
        d["parameters"] = json.loads(d["parameters_json"])
        results.append(d)
    return results

# ----------------- Dashboard Metrics -----------------

def get_dashboard_metrics() -> Dict[str, Any]:
    """Computes real metrics from the database without hardcoded statistics."""
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) AS count FROM captures")
    total_captures = cursor.fetchone()["count"]

    cursor.execute("SELECT COUNT(DISTINCT label) AS count FROM captures WHERE is_reference = 1")
    reference_websites = cursor.fetchone()["count"]

    cursor.execute("SELECT COUNT(*) AS count FROM analyses")
    total_analyses = cursor.fetchone()["count"]

    cursor.execute("SELECT COUNT(*) AS count FROM experiments")
    total_experiments = cursor.fetchone()["count"]

    # Recent 5 captures
    cursor.execute("""
        SELECT id, original_name, label, packet_count, file_size_bytes, is_reference, is_synthetic, created_at
        FROM captures
        ORDER BY id DESC
        LIMIT 5
    """)
    recent_captures = [dict(r) for r in cursor.fetchall()]

    # Label distribution in reference dataset
    cursor.execute("""
        SELECT label, COUNT(*) AS count
        FROM captures
        WHERE is_reference = 1
        GROUP BY label
        ORDER BY count DESC
    """)
    label_distribution = [dict(r) for r in cursor.fetchall()]

    conn.close()
    return {
        "total_captures": total_captures,
        "reference_websites": reference_websites,
        "total_analyses": total_analyses,
        "total_experiments": total_experiments,
        "recent_captures": recent_captures,
        "label_distribution": label_distribution
    }

# ----------------- User Management & Authentication -----------------

def seed_default_users() -> None:
    """Seeds default admin and user accounts if they do not exist."""
    conn = get_db_connection()
    cursor = conn.cursor()

    # Check if admin exists
    cursor.execute("SELECT id FROM users WHERE username = 'admin'")
    if not cursor.fetchone():
        admin_hash = generate_password_hash("admin123")
        cursor.execute("""
            INSERT INTO users (username, password_hash, role, full_name, created_at)
            VALUES (?, ?, ?, ?, ?)
        """, ("admin", admin_hash, "admin", "System Administrator", datetime.now().strftime("%Y-%m-%d %H:%M:%S")))

    # Check if user exists
    cursor.execute("SELECT id FROM users WHERE username = 'user'")
    if not cursor.fetchone():
        user_hash = generate_password_hash("user123")
        cursor.execute("""
            INSERT INTO users (username, password_hash, role, full_name, created_at)
            VALUES (?, ?, ?, ?, ?)
        """, ("user", user_hash, "user", "Research Analyst", datetime.now().strftime("%Y-%m-%d %H:%M:%S")))

    conn.commit()
    conn.close()


def create_user(username: str, password: str, role: str = "user", full_name: Optional[str] = None) -> Optional[int]:
    """Creates a new user record with securely hashed password."""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        pw_hash = generate_password_hash(password)
        cursor.execute("""
            INSERT INTO users (username, password_hash, role, full_name, created_at)
            VALUES (?, ?, ?, ?, ?)
        """, (
            username.strip().lower(),
            pw_hash,
            role.strip().lower() if role in ("admin", "user") else "user",
            full_name.strip() if full_name else username.capitalize(),
            datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        ))
        conn.commit()
        user_id = cursor.lastrowid
        return user_id
    except sqlite3.IntegrityError:
        return None
    finally:
        conn.close()


def get_user_by_username(username: str) -> Optional[Dict[str, Any]]:
    """Retrieves a user by username."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE username = ?", (username.strip().lower(),))
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None


def get_user_by_id(user_id: int) -> Optional[Dict[str, Any]]:
    """Retrieves a user by ID."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE id = ?", (user_id,))
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None


def verify_user(username: str, password: str) -> Optional[Dict[str, Any]]:
    """Verifies username and password against stored hash."""
    user = get_user_by_username(username)
    if not user:
        return None
    if check_password_hash(user["password_hash"], password):
        # Update last login time
        update_last_login(user["id"])
        return user
    return None


def update_last_login(user_id: int) -> None:
    """Updates the last_login timestamp for a user."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "UPDATE users SET last_login = ? WHERE id = ?",
        (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), user_id)
    )
    conn.commit()
    conn.close()


def list_users() -> List[Dict[str, Any]]:
    """Lists all users (excluding raw password hash)."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT id, username, role, full_name, created_at, last_login
        FROM users
        ORDER BY id ASC
    """)
    rows = [dict(r) for r in cursor.fetchall()]
    conn.close()
    return rows


def delete_user(user_id: int) -> bool:
    """Deletes a user account. Cannot delete the root admin."""
    conn = get_db_connection()
    cursor = conn.cursor()
    # Check if target is admin
    cursor.execute("SELECT username FROM users WHERE id = ?", (user_id,))
    row = cursor.fetchone()
    if not row or row["username"] == "admin":
        conn.close()
        return False

    cursor.execute("DELETE FROM users WHERE id = ?", (user_id,))
    conn.commit()
    deleted = cursor.rowcount > 0
    conn.close()
    return deleted


def update_user_role(user_id: int, new_role: str) -> bool:
    """Updates a user's role (user or admin)."""
    if new_role not in ("admin", "user"):
        return False
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET role = ? WHERE id = ?", (new_role, user_id))
    conn.commit()
    updated = cursor.rowcount > 0
    conn.close()
    return updated

