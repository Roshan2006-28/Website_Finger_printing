"""
Unit Tests for Fingerprint Matching Engine.
Tests similarity calculations, identical/distinct vector handling, empty datasets,
and candidate rankings.
"""

import unittest
from matcher import (
    FingerprintMatcher, relative_similarity, log_scale_similarity,
    vector_l1_similarity, cosine_similarity
)


class TestFingerprintMatcher(unittest.TestCase):

    def setUp(self):
        self.sample_fp_wiki = {
            "total_packets": 200,
            "total_bytes": 120000,
            "duration": 2.5,
            "mean_packet_len": 600.0,
            "median_packet_len": 550.0,
            "std_packet_len": 200.0,
            "mean_iat": 0.012,
            "packet_rate": 80.0,
            "has_direction_knowledge": True,
            "direction_ratio": 0.25,
            "size_histogram_normalized": [0.2, 0.2, 0.2, 0.2, 0.1, 0.05, 0.03, 0.02, 0.0],
            "time_volume_normalized": [0.1] * 10
        }

        self.sample_fp_youtube = {
            "total_packets": 800,
            "total_bytes": 1100000,
            "duration": 5.0,
            "mean_packet_len": 1375.0,
            "median_packet_len": 1460.0,
            "std_packet_len": 150.0,
            "mean_iat": 0.006,
            "packet_rate": 160.0,
            "has_direction_knowledge": True,
            "direction_ratio": 0.10,
            "size_histogram_normalized": [0.1, 0.05, 0.02, 0.01, 0.02, 0.05, 0.15, 0.60, 0.0],
            "time_volume_normalized": [0.1] * 10
        }

    def test_identical_fingerprints(self):
        """Verifies that comparing a fingerprint against itself yields 100% similarity."""
        matcher = FingerprintMatcher([])
        res = matcher.compare_pair(self.sample_fp_wiki, self.sample_fp_wiki)
        self.assertEqual(res["overall_similarity"], 100.0)

    def test_distinct_fingerprints(self):
        """Verifies that dissimilar profiles yield substantially lower scores."""
        matcher = FingerprintMatcher([])
        res = matcher.compare_pair(self.sample_fp_wiki, self.sample_fp_youtube)
        self.assertLess(res["overall_similarity"], 75.0)

    def test_empty_reference_dataset(self):
        """Verifies that an empty reference dataset returns EMPTY_DATASET status."""
        matcher = FingerprintMatcher([])
        res = matcher.match(self.sample_fp_wiki)
        self.assertEqual(res["status"], "EMPTY_DATASET")
        self.assertFalse(res["is_conclusive"])
        self.assertEqual(len(res["candidates"]), 0)

    def test_candidate_ranking(self):
        """Verifies that the true match ranks highest in candidate selection."""
        references = [
            {"label": "YouTube", "feature_vector": self.sample_fp_youtube, "capture_id": 1, "original_name": "yt"},
            {"label": "Wikipedia", "feature_vector": self.sample_fp_wiki, "capture_id": 2, "original_name": "wiki"}
        ]
        matcher = FingerprintMatcher(references)
        res = matcher.match(self.sample_fp_wiki)

        self.assertEqual(res["status"], "SUCCESS")
        self.assertTrue(res["is_conclusive"])
        self.assertEqual(res["top_match"]["label"], "Wikipedia")
        self.assertEqual(res["top_match"]["best_score"], 100.0)

    def test_relative_similarity_edge_cases(self):
        """Tests math robustness for relative similarity."""
        self.assertEqual(relative_similarity(0, 0), 1.0)
        self.assertEqual(relative_similarity(100, 100), 1.0)
        self.assertGreater(relative_similarity(100, 95), 0.9)
        self.assertLess(relative_similarity(100, 10), 0.2)

    def test_vector_l1_similarity(self):
        """Tests L1 histogram similarity."""
        v1 = [0.5, 0.5]
        v2 = [0.5, 0.5]
        v3 = [1.0, 0.0]
        self.assertEqual(vector_l1_similarity(v1, v2), 1.0)
        self.assertEqual(vector_l1_similarity(v1, v3), 0.5)


if __name__ == "__main__":
    unittest.main()
