"""
Unit Tests for Authentication and Access Control.
Verifies user hashing, credential verification, role updates, and route authorization.
"""

import unittest
import database
from app import app


class TestAuth(unittest.TestCase):

    def setUp(self):
        database.init_db()
        self.client = app.test_client()
        self.client.testing = True

    def test_default_users_exist(self):
        """Verifies default admin and user accounts are seeded."""
        admin = database.get_user_by_username("admin")
        self.assertIsNotNone(admin)
        self.assertEqual(admin["role"], "admin")

        user = database.get_user_by_username("user")
        self.assertIsNotNone(user)
        self.assertEqual(user["role"], "user")

    def test_verify_user_credentials(self):
        """Verifies password hash validation for valid and invalid credentials."""
        self.assertIsNotNone(database.verify_user("admin", "admin123"))
        self.assertIsNotNone(database.verify_user("user", "user123"))
        self.assertIsNone(database.verify_user("admin", "wrongpassword"))
        self.assertIsNone(database.verify_user("nonexistent", "user123"))

    def test_login_and_logout_flow(self):
        """Tests user session creation and termination."""
        # Valid login
        response = self.client.post("/login", data={"username": "user", "password": "user123"}, follow_redirects=True)
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Analyst workspace ready", response.data)

        # Logout
        response = self.client.get("/logout", follow_redirects=True)
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"terminated safely", response.data)

    def test_admin_route_protection(self):
        """Verifies that non-admin accounts cannot access the admin console."""
        # Unauthenticated access -> redirected to login
        res_unauth = self.client.get("/admin", follow_redirects=True)
        self.assertIn(b"Sign in", res_unauth.data)

        # Logged in as standard user -> access denied
        self.client.post("/login", data={"username": "user", "password": "user123"})
        res_user = self.client.get("/admin", follow_redirects=True)
        self.assertIn(b"Access denied", res_user.data)

        # Logged in as admin -> allowed
        self.client.post("/login", data={"username": "admin", "password": "admin123"})
        res_admin = self.client.get("/admin", follow_redirects=True)
        self.assertIn(b"Administrator Console", res_admin.data)

    def test_content_hidden_until_login(self):
        """Verifies that simulator contents and navigation links are hidden until login."""
        # Unauthenticated: accessing root redirects to login
        res = self.client.get("/", follow_redirects=True)
        self.assertIn(b"Sign in", res.data)
        self.assertNotIn(b'href="/dataset"', res.data)

        # Authenticate
        self.client.post("/login", data={"username": "user", "password": "user123"})
        res_auth = self.client.get("/")
        self.assertEqual(res_auth.status_code, 200)
        self.assertIn(b'href="/dataset"', res_auth.data)
        self.assertIn(b'href="/compare"', res_auth.data)
        self.assertIn(b'href="/experiments"', res_auth.data)



if __name__ == "__main__":
    unittest.main()
