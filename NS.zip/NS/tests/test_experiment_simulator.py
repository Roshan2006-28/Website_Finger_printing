"""
Unit Tests for Experiment Simulator Module.
Tests defensive perturbations: packet padding, timing jitter, background traffic,
truncation, and packet loss.
"""

import unittest
from experiment_simulator import ExperimentSimulator


class TestExperimentSimulator(unittest.TestCase):

    def setUp(self):
        self.simulator = ExperimentSimulator(random_seed=42)
        self.base_summary = {
            "total_packets": 200,
            "total_bytes": 100000,
            "duration": 2.0,
            "mean_packet_len": 500.0,
            "median_packet_len": 500.0,
            "std_packet_len": 200.0,
            "min_packet_len": 64,
            "max_packet_len": 1500,
            "mean_iat": 0.010,
            "median_iat": 0.010,
            "std_iat": 0.005,
            "packets_per_sec": 100.0,
            "bytes_per_sec": 50000.0,
            "size_histogram": [20, 30, 40, 50, 20, 15, 10, 10, 5],
            "time_volume_bins": [10000] * 10,
            "directional": {
                "has_direction_knowledge": True,
                "incoming_packets": 150,
                "outgoing_packets": 50,
                "incoming_bytes": 85000,
                "outgoing_bytes": 15000,
                "direction_ratio": 0.25
            }
        }

    def test_apply_timing_jitter(self):
        """Verifies that timing jitter expands session duration and increases IAT."""
        res = self.simulator.apply_timing_jitter(self.base_summary, max_jitter_ms=50.0)
        self.assertGreater(res["duration"], self.base_summary["duration"])
        self.assertGreater(res["mean_iat"], self.base_summary["mean_iat"])
        self.assertEqual(res["total_packets"], self.base_summary["total_packets"])

    def test_apply_background_traffic(self):
        """Verifies that background traffic injects noise packets and increases total bytes."""
        res = self.simulator.apply_background_traffic(self.base_summary, noise_ratio=0.30)
        self.assertEqual(res["total_packets"], int(self.base_summary["total_packets"] * 1.30))
        self.assertGreater(res["total_bytes"], self.base_summary["total_bytes"])
        self.assertGreater(sum(res["size_histogram"]), sum(self.base_summary["size_histogram"]))

    def test_apply_packet_padding(self):
        """Verifies that packet padding collapses the size distribution to the MTU bin."""
        res = self.simulator.apply_packet_padding(self.base_summary, pad_to_bytes=1460)
        self.assertEqual(res["mean_packet_len"], 1460.0)
        self.assertEqual(res["std_packet_len"], 0.0)
        self.assertEqual(res["size_histogram"][7], self.base_summary["total_packets"])

    def test_apply_capture_truncation(self):
        """Verifies that truncation decreases packet count and duration proportionally."""
        res = self.simulator.apply_capture_truncation(self.base_summary, keep_fraction=0.50)
        self.assertEqual(res["total_packets"], int(self.base_summary["total_packets"] * 0.50))
        self.assertLess(res["duration"], self.base_summary["duration"])

    def test_apply_packet_loss(self):
        """Verifies that packet loss reduces packet count and expands apparent IAT."""
        res = self.simulator.apply_packet_loss(self.base_summary, loss_rate=0.20)
        self.assertLess(res["total_packets"], self.base_summary["total_packets"])
        self.assertGreater(res["mean_iat"], self.base_summary["mean_iat"])


if __name__ == "__main__":
    unittest.main()
