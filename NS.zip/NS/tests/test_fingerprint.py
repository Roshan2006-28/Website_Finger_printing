"""
Unit Tests for Fingerprint Extractor Module.
Tests determinism, vector completeness, handling of empty/short summaries, and normalization.
"""

import unittest
from fingerprint import FingerprintExtractor


class TestFingerprintExtractor(unittest.TestCase):

    def test_extract_feature_vector_completeness(self):
        """Verifies that all required metadata features are present in the vector."""
        sample_summary = {
            "total_packets": 200,
            "total_bytes": 150000,
            "duration": 2.5,
            "mean_packet_len": 750.0,
            "median_packet_len": 800.0,
            "std_packet_len": 250.0,
            "min_packet_len": 64,
            "max_packet_len": 1500,
            "mean_iat": 0.0125,
            "median_iat": 0.010,
            "std_iat": 0.005,
            "packets_per_sec": 80.0,
            "bytes_per_sec": 60000.0,
            "size_histogram": [20, 30, 40, 50, 20, 15, 10, 10, 5],
            "time_volume_bins": [15000] * 10,
            "directional": {
                "has_direction_knowledge": True,
                "incoming_packets": 150,
                "outgoing_packets": 50,
                "incoming_bytes": 130000,
                "outgoing_bytes": 20000,
                "direction_ratio": 0.25
            }
        }

        vec = FingerprintExtractor.extract_feature_vector(sample_summary)

        # Check essential keys
        required_keys = [
            "total_packets", "total_bytes", "duration", "mean_packet_len",
            "median_packet_len", "std_packet_len", "min_packet_len", "max_packet_len",
            "mean_iat", "median_iat", "std_iat", "packet_rate", "byte_rate",
            "has_direction_knowledge", "incoming_packets", "outgoing_packets",
            "incoming_bytes", "outgoing_bytes", "direction_ratio",
            "size_histogram_normalized", "time_volume_normalized"
        ]
        for key in required_keys:
            self.assertIn(key, vec, f"Missing feature: {key}")

        # Check normalization (normalized histogram and temporal profile should sum to ~1.0)
        self.assertAlmostEqual(sum(vec["size_histogram_normalized"]), 1.0, places=4)
        self.assertAlmostEqual(sum(vec["time_volume_normalized"]), 1.0, places=4)

    def test_empty_summary_handling(self):
        """Verifies that an empty summary does not throw ZeroDivisionError."""
        empty_summary = {}
        vec = FingerprintExtractor.extract_feature_vector(empty_summary)
        self.assertEqual(vec["total_packets"], 0)
        self.assertEqual(vec["total_bytes"], 0)
        self.assertGreater(vec["duration"], 0.0)
        self.assertEqual(sum(vec["size_histogram_normalized"]), 0.0)

    def test_determinism(self):
        """Verifies that identical summaries produce identical feature vectors."""
        summary = {
            "total_packets": 100,
            "total_bytes": 50000,
            "duration": 1.2,
            "mean_packet_len": 500.0,
            "size_histogram": [10, 10, 10, 10, 10, 10, 10, 10, 20],
            "time_volume_bins": [5000] * 10
        }
        vec1 = FingerprintExtractor.extract_feature_vector(summary)
        vec2 = FingerprintExtractor.extract_feature_vector(summary)
        self.assertEqual(vec1, vec2)


if __name__ == "__main__":
    unittest.main()
