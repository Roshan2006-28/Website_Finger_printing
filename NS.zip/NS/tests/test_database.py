"""
Unit Tests for Database Module.
Tests schema initialization, CRUD operations, parameterized security, and foreign key cascades.
"""

import os
import tempfile
import unittest
import database


class TestDatabase(unittest.TestCase):

    def setUp(self):
        self.temp_db = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        self.original_db_path = database.DATABASE_PATH
        database.DATABASE_PATH = self.temp_db.name
        database.init_db()

    def tearDown(self):
        database.DATABASE_PATH = self.original_db_path
        self.temp_db.close()
        if os.path.exists(self.temp_db.name):
            os.remove(self.temp_db.name)

    def test_insert_and_get_capture(self):
        """Tests insertion and retrieval of capture metadata."""
        cap_id = database.insert_capture(
            filename="test_cap.pcap",
            original_name="Test Capture",
            label="Wikipedia",
            packet_count=150,
            file_size_bytes=45000,
            duration=1.8,
            is_synthetic=True,
            is_reference=True
        )
        self.assertGreater(cap_id, 0)

        record = database.get_capture(cap_id)
        self.assertIsNotNone(record)
        self.assertEqual(record["label"], "Wikipedia")
        self.assertEqual(record["packet_count"], 150)
        self.assertEqual(record["is_reference"], 1)

    def test_store_and_get_fingerprint(self):
        """Tests storing and retrieving fingerprint feature vectors."""
        cap_id = database.insert_capture(
            filename="fp_cap.pcap",
            original_name="FP Capture",
            label="YouTube",
            packet_count=500
        )
        f_vec = {"total_packets": 500, "mean_packet_len": 1200.0}
        summary = {"bytes": 600000}

        fp_id = database.store_fingerprint(cap_id, "YouTube", f_vec, summary)
        self.assertGreater(fp_id, 0)

        fp_rec = database.get_fingerprint_by_capture(cap_id)
        self.assertIsNotNone(fp_rec)
        self.assertEqual(fp_rec["label"], "YouTube")
        self.assertEqual(fp_rec["feature_vector"]["total_packets"], 500)

    def test_sql_injection_safety(self):
        """Tests that malicious label inputs do not break queries or inject SQL."""
        malicious_label = "Wikipedia'; DROP TABLE captures; --"
        cap_id = database.insert_capture(
            filename="malicious.pcap",
            original_name="Malicious Name",
            label=malicious_label
        )
        rec = database.get_capture(cap_id)
        self.assertEqual(rec["label"], malicious_label)

        # Confirm captures table still intact
        caps = database.list_captures()
        self.assertGreaterEqual(len(caps), 1)

    def test_delete_capture_cascade(self):
        """Tests that deleting a capture cascades to remove the associated fingerprint."""
        cap_id = database.insert_capture(
            filename="del_cap.pcap",
            original_name="To Delete",
            label="TestSite"
        )
        database.store_fingerprint(cap_id, "TestSite", {"total_packets": 10}, {})

        del_filename = database.delete_capture(cap_id)
        self.assertEqual(del_filename, "del_cap.pcap")
        self.assertIsNone(database.get_capture(cap_id))
        self.assertIsNone(database.get_fingerprint_by_capture(cap_id))


if __name__ == "__main__":
    unittest.main()
