"""
Unit Tests for Packet Metadata Analyzer Module.
Tests parsing of empty files, malformed PCAPs, short captures, and missing timestamps.
"""

import os
import tempfile
import unittest
from scapy.all import Ether, IP, TCP, wrpcap
from packet_analyzer import PacketAnalyzer, infer_client_ip, is_private_ip


class TestPacketAnalyzer(unittest.TestCase):

    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()

    def tearDown(self):
        import gc
        gc.collect()
        try:
            self.temp_dir.cleanup()
        except Exception:
            pass

    def test_empty_pcap_file(self):
        """Tests that an empty 0-byte file is handled gracefully without crashing."""
        empty_path = os.path.join(self.temp_dir.name, "empty.pcap")
        with open(empty_path, "wb") as f:
            pass  # 0 bytes

        analyzer = PacketAnalyzer(empty_path)
        summary = analyzer.analyze()
        self.assertIn("error", summary)
        self.assertEqual(summary["error"], "Capture file is empty (0 bytes).")

    def test_nonexistent_file(self):
        """Tests that non-existent paths return an informative error."""
        analyzer = PacketAnalyzer("non_existent_file.pcap")
        summary = analyzer.analyze()
        self.assertIn("error", summary)
        self.assertIn("not found", summary["error"])

    def test_malformed_capture_file(self):
        """Tests that random corrupt binary data is handled gracefully."""
        corrupt_path = os.path.join(self.temp_dir.name, "corrupt.pcap")
        with open(corrupt_path, "wb") as f:
            f.write(b"NOT_A_VALID_PCAP_MAGIC_HEADER_RANDOM_GARBAGE_1234567890")

        analyzer = PacketAnalyzer(corrupt_path)
        summary = analyzer.analyze()
        self.assertIn("error", summary)
        self.assertIn("Failed to parse", summary["error"])

    def test_valid_pcap_analysis(self):
        """Tests standard metadata extraction on a valid synthetic packet trace."""
        pcap_path = os.path.join(self.temp_dir.name, "valid.pcap")
        packets = []

        for i in range(10):
            pkt = Ether() / IP(src="192.168.1.50", dst="93.184.216.34") / TCP(sport=50000+i, dport=443) / (b"X" * (100 * (i + 1)))
            pkt.time = 1000.0 + (i * 0.05)
            packets.append(pkt)

        wrpcap(pcap_path, packets)

        analyzer = PacketAnalyzer(pcap_path, client_ip="192.168.1.50")
        summary = analyzer.analyze()

        self.assertNotIn("error", summary)
        self.assertEqual(summary["total_packets"], 10)
        self.assertGreater(summary["total_bytes"], 0)
        self.assertAlmostEqual(summary["duration"], 0.45, places=2)
        self.assertEqual(summary["directional"]["outgoing_packets"], 10)
        self.assertEqual(summary["directional"]["incoming_packets"], 0)

    def test_short_capture_one_packet(self):
        """Tests edge case where capture contains only 1 packet."""
        pcap_path = os.path.join(self.temp_dir.name, "single.pcap")
        pkt = Ether() / IP(src="192.168.1.2", dst="8.8.8.8") / TCP(sport=12345, dport=53)
        pkt.time = 100.0
        wrpcap(pcap_path, [pkt])

        analyzer = PacketAnalyzer(pcap_path)
        summary = analyzer.analyze()

        self.assertNotIn("error", summary)
        self.assertEqual(summary["total_packets"], 1)
        self.assertGreaterEqual(summary["duration"], 0.0)

    def test_missing_directional_knowledge(self):
        """Tests that when direction cannot be inferred, directional flags indicate unknown."""
        pcap_path = os.path.join(self.temp_dir.name, "public_only.pcap")
        # Traffic between two public addresses with no SYN packets
        pkt = Ether() / IP(src="93.184.216.34", dst="151.101.1.69") / TCP(sport=443, dport=443)
        pkt.time = 50.0
        wrpcap(pcap_path, [pkt])

        analyzer = PacketAnalyzer(pcap_path, client_ip=None)
        summary = analyzer.analyze()

        self.assertNotIn("error", summary)
        self.assertIn("directional", summary)

    def test_private_ip_detection(self):
        """Tests IPv4 private range detection utility."""
        self.assertTrue(is_private_ip("192.168.1.1"))
        self.assertTrue(is_private_ip("10.0.0.5"))
        self.assertTrue(is_private_ip("172.16.0.1"))
        self.assertTrue(is_private_ip("172.31.255.255"))
        self.assertTrue(is_private_ip("127.0.0.1"))
        self.assertFalse(is_private_ip("8.8.8.8"))
        self.assertFalse(is_private_ip("93.184.216.34"))


if __name__ == "__main__":
    unittest.main()
