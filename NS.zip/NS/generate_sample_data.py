"""
Sample PCAP and Dataset Generator for Website Fingerprinting Attack Simulator.
Generates realistic synthetic PCAP files using Scapy and seeds the SQLite database
with reference website fingerprints for safe offline demonstration.
"""

import os
import random
import time
from typing import List, Dict, Any

from scapy.all import Ether, IP, TCP, wrpcap
import config
from database import init_db, insert_capture, store_fingerprint
from packet_analyzer import PacketAnalyzer
from fingerprint import FingerprintExtractor

# Profile definitions representing observable traffic metadata for distinct website archetypes
WEBSITE_PROFILES = {
    "Wikipedia": {
        "description": "Encyclopedic article: text-heavy, moderate scripts, balanced sizes",
        "packet_count_range": (180, 260),
        "duration_range": (1.8, 3.2),
        "client_ratio": 0.28,
        "size_patterns": [
            (64, 96, 0.25),     # TCP ACKs & TLS ACKs
            (250, 600, 0.35),   # HTML chunks and API queries
            (1100, 1420, 0.40)  # Compressed text and thumbnail assets
        ]
    },
    "YouTube": {
        "description": "Video streaming: massive incoming throughput, heavy MTU packets, low client ratio",
        "packet_count_range": (500, 750),
        "duration_range": (4.0, 7.5),
        "client_ratio": 0.12,
        "size_patterns": [
            (64, 80, 0.15),     # Rapid ACKs
            (300, 600, 0.05),   # Handshake and manifests
            (1420, 1514, 0.80)  # Full MTU media segments
        ]
    },
    "DuckDuckGo": {
        "description": "Privacy search: lightweight, rapid transaction, low total volume",
        "packet_count_range": (45, 75),
        "duration_range": (0.6, 1.2),
        "client_ratio": 0.42,
        "size_patterns": [
            (64, 110, 0.45),    # Client search queries & ACKs
            (400, 950, 0.45),   # Instant search result HTML
            (1200, 1420, 0.10)  # Favicon/script
        ]
    },
    "GitHub": {
        "description": "Developer repository: mixed bidirectional traffic, code blocks, JSON payloads",
        "packet_count_range": (280, 420),
        "duration_range": (2.5, 4.5),
        "client_ratio": 0.30,
        "size_patterns": [
            (64, 120, 0.30),    # ACKs and TLS Handshake
            (450, 850, 0.30),   # Markdown rendered fragments & CSS
            (1200, 1480, 0.40)  # Code payloads and icons
        ]
    },
    "NewsPortal": {
        "description": "News portal: ad networks, image carousels, bursty multi-CDN downloads",
        "packet_count_range": (400, 600),
        "duration_range": (3.5, 6.0),
        "client_ratio": 0.22,
        "size_patterns": [
            (64, 96, 0.25),     # ACKs
            (200, 700, 0.35),   # Multi-script tracking calls
            (1250, 1500, 0.40)  # Image banners and media
        ]
    }
}


def synthesize_pcap(filepath: str, profile_name: str, client_ip: str = "192.168.1.105", server_ip: str = "104.26.10.42", seed_offset: int = 0):
    """
    Synthesizes a realistic PCAP file reflecting the specified website traffic profile.
    """
    random.seed(42 + seed_offset)
    profile = WEBSITE_PROFILES[profile_name]

    pkt_count = random.randint(*profile["packet_count_range"])
    duration = random.uniform(*profile["duration_range"])
    client_ratio = profile["client_ratio"]
    patterns = profile["size_patterns"]

    packets = []
    base_time = 1770000000.0 + (seed_offset * 1000)
    current_time = base_time

    # TCP Handshake Simulation
    syn_pkt = Ether() / IP(src=client_ip, dst=server_ip) / TCP(sport=54321 + seed_offset, dport=443, flags="S", seq=1000)
    syn_pkt.time = current_time
    packets.append(syn_pkt)

    current_time += 0.015
    syn_ack = Ether() / IP(src=server_ip, dst=client_ip) / TCP(sport=443, dport=54321 + seed_offset, flags="SA", seq=2000, ack=1001)
    syn_ack.time = current_time
    packets.append(syn_ack)

    current_time += 0.014
    ack_pkt = Ether() / IP(src=client_ip, dst=server_ip) / TCP(sport=54321 + seed_offset, dport=443, flags="A", seq=1001, ack=2001)
    ack_pkt.time = current_time
    packets.append(ack_pkt)

    # Generate remaining data packets distributed across the session duration
    time_step = duration / max(1, (pkt_count - 3))

    for i in range(3, pkt_count):
        # Add random jitter to inter-arrival time
        jitter = random.uniform(-0.4, 0.6) * time_step
        current_time += max(0.0002, time_step + jitter)

        # Decide packet direction
        is_outgoing = random.random() < client_ratio
        src = client_ip if is_outgoing else server_ip
        dst = server_ip if is_outgoing else client_ip
        sp = 54321 + seed_offset if is_outgoing else 443
        dp = 443 if is_outgoing else 54321 + seed_offset

        # Pick size distribution
        rand_val = random.random()
        cum_prob = 0.0
        min_sz, max_sz = 64, 1500
        for low, high, prob in patterns:
            cum_prob += prob
            if rand_val <= cum_prob:
                min_sz, max_sz = low, high
                break

        chosen_size = random.randint(min_sz, max_sz)
        # Construct packet with wire length matching chosen_size
        raw_payload_len = max(0, chosen_size - 54) # 14 Eth + 20 IP + 20 TCP = 54B
        payload = b"\x00" * raw_payload_len

        pkt = Ether() / IP(src=src, dst=dst) / TCP(sport=sp, dport=dp, flags="PA" if raw_payload_len > 0 else "A") / payload
        pkt.time = current_time
        packets.append(pkt)

    wrpcap(filepath, packets)


def generate_all_sample_datasets():
    """
    Generates reference PCAP captures for all 5 sample sites (2 captures each),
    plus an unknown evaluation capture, and saves them to sample_data/.
    """
    os.makedirs(config.SAMPLE_DATA_DIR, exist_ok=True)
    os.makedirs(config.CAPTURES_DIR, exist_ok=True)

    print("[*] Initializing SQLite database schema...")
    init_db()

    print("[*] Generating reference PCAP captures for 5 websites...")
    generated_files = []

    seed = 100
    for site in WEBSITE_PROFILES.keys():
        for run in range(1, 3):
            seed += 1
            filename = f"ref_{site.lower()}_run{run}.pcap"
            filepath = os.path.join(config.CAPTURES_DIR, filename)
            synthesize_pcap(filepath, site, seed_offset=seed)
            print(f"    [+] Created reference PCAP: {filename}")

            # Analyze and register in DB
            analyzer = PacketAnalyzer(filepath)
            summary = analyzer.analyze()
            f_vec = FingerprintExtractor.extract_feature_vector(summary)

            cap_id = insert_capture(
                filename=filename,
                original_name=f"{site} Reference Session (Run #{run})",
                label=site,
                capture_time=time.strftime("%Y-%m-%d %H:%M:%S"),
                packet_count=summary["total_packets"],
                file_size_bytes=summary["file_size_bytes"],
                duration=summary["duration"],
                is_synthetic=True,
                is_reference=True
            )

            store_fingerprint(cap_id, site, f_vec, summary)
            generated_files.append(filepath)

    # Generate an unknown evaluation sample (Wikipedia with slight variance)
    unknown_filename = "unknown_test_capture.pcap"
    unknown_filepath = os.path.join(config.CAPTURES_DIR, unknown_filename)
    synthesize_pcap(unknown_filepath, "Wikipedia", seed_offset=999)
    print(f"    [+] Created unknown test PCAP: {unknown_filename} (True origin: Wikipedia)")

    analyzer = PacketAnalyzer(unknown_filepath)
    summary = analyzer.analyze()
    f_vec = FingerprintExtractor.extract_feature_vector(summary)

    unk_cap_id = insert_capture(
        filename=unknown_filename,
        original_name="Unknown HTTPS Session (Evaluation Sample)",
        label="Unknown",
        capture_time=time.strftime("%Y-%m-%d %H:%M:%S"),
        packet_count=summary["total_packets"],
        file_size_bytes=summary["file_size_bytes"],
        duration=summary["duration"],
        is_synthetic=True,
        is_reference=False
    )
    store_fingerprint(unk_cap_id, "Unknown", f_vec, summary)

    print("\n[OK] Sample dataset generation and database seeding complete!")
    print(f"[OK] Stored 10 reference captures and 1 unknown evaluation capture in: {config.CAPTURES_DIR}")


if __name__ == "__main__":
    generate_all_sample_datasets()
