"""
Website Fingerprinting Attack Simulator - Flask Application.
Local, privacy-preserving academic framework for analyzing encrypted network traffic metadata.
"""

import os
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"
os.environ["OMP_NUM_THREADS"] = "1"

import time
import json
from datetime import datetime
from functools import wraps
from werkzeug.utils import secure_filename
from flask import (
    Flask, render_template, request, redirect, url_for,
    flash, jsonify, send_file, Response, session
)

import config
from database import (
    init_db, insert_capture, get_capture, list_captures, delete_capture,
    store_fingerprint, get_fingerprint_by_capture, list_reference_fingerprints,
    get_repeated_captures, log_analysis, list_analyses, log_experiment,
    list_experiments, get_dashboard_metrics,
    verify_user, get_user_by_id, get_user_by_username, create_user,
    list_users, delete_user, update_user_role
)
from packet_analyzer import PacketAnalyzer
from fingerprint import FingerprintExtractor
from matcher import FingerprintMatcher
from experiment_simulator import ExperimentSimulator
from report_generator import ReportGenerator

app = Flask(__name__)
app.config["SECRET_KEY"] = config.SECRET_KEY
app.config["MAX_CONTENT_LENGTH"] = config.MAX_CONTENT_LENGTH

# Initialize database schema on startup
init_db()


def login_required(f):
    """Ensures a user is authenticated."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if "user_id" not in session:
            flash("Please sign in to access this feature.", "warning")
            return redirect(url_for("login", next=request.url))
        return f(*args, **kwargs)
    return decorated_function


def admin_required(f):
    """Ensures an administrator is authenticated."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if "user_id" not in session:
            flash("Administrator login required.", "warning")
            return redirect(url_for("login", next=request.url))
        if session.get("role") != "admin":
            flash("Access denied: Administrative privileges required.", "danger")
            return redirect(url_for("index"))
        return f(*args, **kwargs)
    return decorated_function


@app.context_processor
def inject_auth_user():
    """Injects current logged in user details into all templates."""
    current_user = None
    if "user_id" in session:
        current_user = {
            "id": session.get("user_id"),
            "username": session.get("username"),
            "role": session.get("role"),
            "full_name": session.get("full_name")
        }
    return dict(current_user=current_user)


@app.before_request
def require_login():
    """Restricts all application content to authenticated users only."""
    allowed_endpoints = {"login", "register", "static"}
    if request.endpoint and request.endpoint in allowed_endpoints:
        return None
    if "user_id" not in session:
        return redirect(url_for("login", next=request.url if request.method == "GET" else None))


def allowed_file(filename: str) -> bool:
    """Validates file extension against allowed capture formats."""
    return "." in filename and filename.rsplit(".", 1)[1].lower() in config.ALLOWED_EXTENSIONS



# ----------------- AUTHENTICATION & ACCESS CONTROL -----------------

@app.route("/login", methods=["GET", "POST"])
def login():
    """Authenticates analysts and administrators."""
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()
        next_url = request.form.get("next") or request.args.get("next")

        if not username or not password:
            flash("Please provide both username and password.", "warning")
            return render_template("login.html")

        user = verify_user(username, password)
        if user:
            session.clear()
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            session["role"] = user["role"]
            session["full_name"] = user.get("full_name") or user["username"]

            if user["role"] == "admin":
                flash(f"Welcome back, Administrator '{user['username']}'. Privileged access activated.", "success")
                return redirect(next_url or url_for("admin_dashboard"))
            else:
                flash(f"Welcome back, {user.get('full_name', user['username'])}. Analyst workspace ready.", "success")
                return redirect(next_url or url_for("index"))
        else:
            flash("Invalid credentials. Please verify your username and password.", "danger")

    return render_template("login.html")


@app.route("/logout")
def logout():
    """Safely signs out the current user and clears session state."""
    uname = session.get("username", "Analyst")
    session.clear()
    flash(f"Session for '{uname}' terminated safely.", "info")
    return redirect(url_for("login"))


@app.route("/register", methods=["GET", "POST"])
def register():
    """Provisions a new research analyst user account."""
    if request.method == "POST":
        full_name = request.form.get("full_name", "").strip()
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()
        confirm_password = request.form.get("confirm_password", "").strip()

        if not username or not password:
            flash("Username and password are required.", "warning")
            return render_template("register.html")

        if len(username) < 3:
            flash("Username must be at least 3 characters long.", "warning")
            return render_template("register.html")

        if password != confirm_password:
            flash("Passwords do not match.", "danger")
            return render_template("register.html")

        if len(password) < 4:
            flash("Password must be at least 4 characters long.", "warning")
            return render_template("register.html")

        user_id = create_user(username, password, role="user", full_name=full_name)
        if not user_id:
            flash(f"Username '{username}' is already in use. Please select a different username.", "danger")
            return render_template("register.html")

        flash("Account provisioned successfully! You can now log in.", "success")
        return redirect(url_for("login"))

    return render_template("register.html")


@app.route("/admin")
@admin_required
def admin_dashboard():
    """Administrator control console for user management and platform health."""
    users = list_users()
    metrics = get_dashboard_metrics()
    return render_template("admin.html", users=users, metrics=metrics)


@app.route("/admin/user/create", methods=["POST"])
@admin_required
def admin_create_user():
    """Provisions an analyst or administrator account directly from console."""
    username = request.form.get("username", "").strip()
    full_name = request.form.get("full_name", "").strip()
    password = request.form.get("password", "").strip()
    role = request.form.get("role", "user").strip()

    if not username or not password:
        flash("Username and temporary password are required.", "warning")
        return redirect(url_for("admin_dashboard"))

    user_id = create_user(username, password, role=role, full_name=full_name)
    if user_id:
        flash(f"Account '{username}' ({role.upper()}) provisioned successfully.", "success")
    else:
        flash(f"Could not provision account: username '{username}' already exists.", "danger")

    return redirect(url_for("admin_dashboard"))


@app.route("/admin/user/role/<int:user_id>", methods=["POST"])
@admin_required
def admin_toggle_role(user_id):
    """Elevates or demotes user account permissions."""
    new_role = request.form.get("new_role", "user")
    if update_user_role(user_id, new_role):
        flash(f"Role updated successfully for user #{user_id} to '{new_role}'.", "success")
    else:
        flash("Unable to update account role.", "danger")
    return redirect(url_for("admin_dashboard"))


@app.route("/admin/user/delete/<int:user_id>", methods=["POST"])
@admin_required
def admin_delete_user(user_id):
    """Deletes a user account. Root admin account is permanently protected."""
    if delete_user(user_id):
        flash(f"User account #{user_id} removed successfully.", "success")
    else:
        flash("Unable to delete user. The root administrator account cannot be deleted.", "danger")
    return redirect(url_for("admin_dashboard"))


# ----------------- MAIN APP ROUTES -----------------

@app.route("/")
def index():
    """Dashboard page showing system overview, real metrics, and recent activity."""
    metrics = get_dashboard_metrics()
    recent_analyses = list_analyses(limit=5)
    recent_experiments = list_experiments(limit=5)
    return render_template(
        "index.html",
        metrics=metrics,
        recent_analyses=recent_analyses,
        recent_experiments=recent_experiments
    )


@app.route("/upload", methods=["GET", "POST"])
def upload():
    """Import PCAP captures, synthesize test traffic, or trigger optional live capture."""
    if request.method == "POST":
        action = request.form.get("action", "upload")

        # 1. Synthesize Traffic Profile directly from UI
        if action == "synthesize":
            from generate_sample_data import synthesize_pcap, WEBSITE_PROFILES
            profile = request.form.get("profile", "Wikipedia")
            if profile not in WEBSITE_PROFILES:
                flash(f"Invalid profile '{profile}' requested.", "danger")
                return redirect(url_for("upload"))

            label = request.form.get("label", profile).strip() or profile
            is_ref = request.form.get("is_reference") == "1"
            safe_name = f"synth_{profile.lower()}_{int(time.time())}.pcap"
            save_path = os.path.join(config.CAPTURES_DIR, safe_name)

            synthesize_pcap(save_path, profile, seed_offset=int(time.time()) % 1000)

            # Analyze and register
            analyzer = PacketAnalyzer(save_path)
            summary = analyzer.analyze()
            f_vec = FingerprintExtractor.extract_feature_vector(summary)

            cap_id = insert_capture(
                filename=safe_name,
                original_name=f"Synthesized {profile} Traffic",
                label=label,
                capture_time=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                packet_count=summary["total_packets"],
                file_size_bytes=summary["file_size_bytes"],
                duration=summary["duration"],
                is_synthetic=True,
                is_reference=is_ref
            )
            store_fingerprint(cap_id, label, f_vec, summary)

            flash(f"Successfully generated and analyzed synthetic capture for '{profile}'.", "success")
            return redirect(url_for("analysis", capture_id=cap_id))

        # 2. File Upload Handling
        if "pcap_file" not in request.files:
            flash("No file was submitted in the request.", "warning")
            return redirect(url_for("upload"))

        file = request.files["pcap_file"]
        if file.filename == "":
            flash("Please select a PCAP file to upload.", "warning")
            return redirect(url_for("upload"))

        if not allowed_file(file.filename):
            flash(f"Invalid format. Allowed capture formats: {', '.join(config.ALLOWED_EXTENSIONS)}", "danger")
            return redirect(url_for("upload"))

        original_filename = secure_filename(file.filename)
        timestamp_prefix = int(time.time())
        safe_filename = f"{timestamp_prefix}_{original_filename}"
        save_path = os.path.join(config.CAPTURES_DIR, safe_filename)

        file.save(save_path)

        # Extract form parameters
        label = request.form.get("label", "Unknown").strip() or "Unknown"
        is_reference = request.form.get("is_reference") == "1"
        client_ip = request.form.get("client_ip", "").strip() or None

        # Parse PCAP
        analyzer = PacketAnalyzer(save_path, client_ip=client_ip)
        summary = analyzer.analyze()

        if "error" in summary:
            # Clean up failed upload
            if os.path.exists(save_path):
                os.remove(save_path)
            flash(f"Parsing failed: {summary['error']}", "danger")
            return redirect(url_for("upload"))

        # Extract deterministic fingerprint
        feature_vector = FingerprintExtractor.extract_feature_vector(summary)

        # Store in database
        capture_id = insert_capture(
            filename=safe_filename,
            original_name=original_filename,
            label=label,
            capture_time=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            packet_count=summary["total_packets"],
            file_size_bytes=summary["file_size_bytes"],
            duration=summary["duration"],
            is_synthetic=False,
            is_reference=is_reference
        )
        store_fingerprint(capture_id, label, feature_vector, summary)

        flash(f"Capture successfully uploaded and analyzed: #{capture_id} ({summary['total_packets']} packets)", "success")
        return redirect(url_for("analysis", capture_id=capture_id))

    return render_template("upload.html")


@app.route("/analysis/<int:capture_id>")
def analysis(capture_id: int):
    """Deep-dive traffic metadata analysis page for a specific capture."""
    cap = get_capture(capture_id)
    if not cap:
        flash(f"Capture #{capture_id} does not exist.", "warning")
        return redirect(url_for("index"))

    fp_record = get_fingerprint_by_capture(capture_id)
    if not fp_record:
        flash("Fingerprint data missing for this capture.", "danger")
        return redirect(url_for("index"))

    return render_template(
        "analysis.html",
        capture=cap,
        fingerprint=fp_record["feature_vector"],
        summary=fp_record["summary"],
        summary_json=json.dumps(fp_record["summary"])
    )


@app.route("/dataset")
def dataset():
    """Reference Fingerprint Dataset manager page."""
    search_q = request.args.get("q", "").strip()
    selected_label = request.args.get("compare_label", "").strip()

    references = list_reference_fingerprints()
    if search_q:
        references = [r for r in references if search_q.lower() in r["label"].lower() or search_q.lower() in r["original_name"].lower()]

    # Repeated capture inspection
    repeated_samples = []
    if selected_label:
        repeated_samples = get_repeated_captures(selected_label)

    # Distinct labels in reference dataset
    distinct_labels = sorted(list(set(r["label"] for r in list_reference_fingerprints())))

    return render_template(
        "dataset.html",
        references=references,
        distinct_labels=distinct_labels,
        selected_label=selected_label,
        repeated_samples=repeated_samples,
        search_q=search_q
    )


@app.route("/dataset/delete/<int:capture_id>", methods=["POST"])
@admin_required
def delete_capture_route(capture_id: int):
    """Removes a capture and associated fingerprints safely."""
    cap = get_capture(capture_id)
    if not cap:
        flash("Capture not found.", "warning")
        return redirect(url_for("dataset"))

    filename = delete_capture(capture_id)
    if filename:
        pcap_path = os.path.join(config.CAPTURES_DIR, filename)
        if os.path.exists(pcap_path):
            os.remove(pcap_path)

    flash(f"Capture #{capture_id} ('{cap['original_name']}') successfully deleted.", "info")
    return redirect(url_for("dataset"))


@app.route("/compare", methods=["GET", "POST"])
def compare():
    """Fingerprint comparison engine page comparing unknown traffic to reference database."""
    all_captures = list_captures()
    references = list_reference_fingerprints()

    selected_capture_id = request.args.get("capture_id", type=int)
    comparison_result = None
    target_capture = None
    target_fingerprint = None

    if selected_capture_id:
        target_capture = get_capture(selected_capture_id)
        if target_capture:
            fp_data = get_fingerprint_by_capture(selected_capture_id)
            if fp_data:
                target_fingerprint = fp_data["feature_vector"]
                matcher = FingerprintMatcher(references)
                comparison_result = matcher.match(target_fingerprint)

                # Log analysis record
                top_match = comparison_result.get("top_match")
                log_analysis(
                    capture_id=selected_capture_id,
                    results=comparison_result,
                    top_match_label=top_match["label"] if top_match else None,
                    similarity_score=top_match["best_score"] if top_match else None
                )

    return render_template(
        "compare.html",
        all_captures=all_captures,
        selected_capture_id=selected_capture_id,
        target_capture=target_capture,
        target_fingerprint=target_fingerprint,
        comparison_result=comparison_result,
        comparison_json=json.dumps(comparison_result) if comparison_result else "null",
        reference_count=len(references)
    )


@app.route("/experiments", methods=["GET", "POST"])
def experiments():
    """Controlled Experiment Lab to test defensive mechanisms and noise perturbations."""
    all_captures = list_captures()
    references = list_reference_fingerprints()
    experiment_result = None

    if request.method == "POST":
        capture_id = request.form.get("capture_id", type=int)
        scenario_id = request.form.get("scenario_id", "packet_padding")

        cap = get_capture(capture_id) if capture_id else None
        fp_rec = get_fingerprint_by_capture(capture_id) if capture_id else None

        if not cap or not fp_rec:
            flash("Please select a valid baseline capture for the experiment.", "warning")
            return redirect(url_for("experiments"))

        params = {}
        if scenario_id == "timing_jitter":
            params["max_jitter_ms"] = float(request.form.get("max_jitter_ms", 50.0))
        elif scenario_id == "background_traffic":
            params["noise_ratio"] = float(request.form.get("noise_ratio", 0.35))
        elif scenario_id == "packet_padding":
            params["pad_to_bytes"] = int(request.form.get("pad_to_bytes", 1460))
        elif scenario_id == "capture_truncation":
            params["keep_fraction"] = float(request.form.get("keep_fraction", 0.40))
        elif scenario_id == "packet_loss":
            params["loss_rate"] = float(request.form.get("loss_rate", 0.20))

        simulator = ExperimentSimulator(random_seed=42)
        experiment_result = simulator.run_experiment(
            scenario_id=scenario_id,
            baseline_summary=fp_rec["summary"],
            reference_fingerprints=references,
            scenario_params=params
        )

        # Log experiment to database
        log_experiment(
            scenario_name=experiment_result["scenario_name"],
            baseline_capture_id=capture_id,
            modified_capture_id=None,
            baseline_score=experiment_result["baseline_score"],
            modified_score=experiment_result["modified_score"],
            score_delta=experiment_result["score_delta"],
            parameters=params
        )

    return render_template(
        "experiments.html",
        all_captures=all_captures,
        experiment_result=experiment_result,
        experiment_json=json.dumps(experiment_result) if experiment_result else "null"
    )


@app.route("/reports")
def reports():
    """Reports page for exporting CSV, JSON, and Markdown summaries."""
    captures = list_captures()
    analyses = list_analyses(limit=20)
    experiments_list = list_experiments(limit=20)
    return render_template(
        "reports.html",
        captures=captures,
        analyses=analyses,
        experiments=experiments_list
    )


@app.route("/reports/export/csv")
def export_csv():
    """Exports all capture summaries in CSV format."""
    captures = list_captures()
    csv_data = ReportGenerator.generate_csv_summary(captures)
    return Response(
        csv_data,
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment;filename=website_fingerprinting_captures.csv"}
    )


@app.route("/reports/export/json/<int:capture_id>")
def export_json(capture_id: int):
    """Exports a single capture's fingerprint and latest matching result in JSON."""
    cap = get_capture(capture_id)
    fp = get_fingerprint_by_capture(capture_id)
    if not cap or not fp:
        flash("Capture not found.", "warning")
        return redirect(url_for("reports"))

    # Match against references for full export
    refs = list_reference_fingerprints()
    matcher = FingerprintMatcher(refs)
    match_result = matcher.match(fp["feature_vector"])

    json_str = ReportGenerator.generate_json_export(cap, fp, match_result)
    return Response(
        json_str,
        mimetype="application/json",
        headers={"Content-Disposition": f"attachment;filename=fingerprint_capture_{capture_id}.json"}
    )


@app.route("/reports/export/markdown/<int:capture_id>")
def export_markdown(capture_id: int):
    """Exports a single capture's academic research report in Markdown."""
    cap = get_capture(capture_id)
    fp = get_fingerprint_by_capture(capture_id)
    if not cap or not fp:
        flash("Capture not found.", "warning")
        return redirect(url_for("reports"))

    refs = list_reference_fingerprints()
    matcher = FingerprintMatcher(refs)
    match_result = matcher.match(fp["feature_vector"])

    md_str = ReportGenerator.generate_markdown_report(cap, fp, match_result)
    return Response(
        md_str,
        mimetype="text/markdown",
        headers={"Content-Disposition": f"attachment;filename=fingerprint_report_capture_{capture_id}.md"}
    )


@app.route("/about")
def about():
    """Project background, methodology, threat model, and defense principles."""
    features_doc = FingerprintExtractor.get_feature_documentation()
    return render_template("about.html", features_doc=features_doc)


# ----------------- OPTIONAL LIVE CAPTURE API -----------------

@app.route("/api/live_capture", methods=["POST"])
def live_capture():
    """
    Optional live capture endpoint with explicit user consent.
    Strictly local, payload-agnostic, with duration safety cap.
    """
    if not config.LIVE_CAPTURE_ENABLED:
        return jsonify({"success": False, "error": "Live capture is disabled in configuration."}), 403

    data = request.get_json() or {}
    consent = data.get("explicit_user_authorization", False)
    if not consent:
        return jsonify({"success": False, "error": "Explicit user authorization required for live monitoring."}), 400

    duration = min(int(data.get("duration", 10)), config.MAX_LIVE_CAPTURE_DURATION)
    interface = data.get("interface", config.DEFAULT_CAPTURE_INTERFACE)
    label = data.get("label", "Live_Capture").strip() or "Live_Capture"

    try:
        from scapy.all import sniff, wrpcap
        timestamp = int(time.time())
        filename = f"live_{timestamp}.pcap"
        save_path = os.path.join(config.CAPTURES_DIR, filename)

        # Sniff packets without payload inspection
        packets = sniff(iface=interface, timeout=duration, count=1000)
        if len(packets) == 0:
            return jsonify({"success": False, "error": "No packets captured during the interval."}), 400

        wrpcap(save_path, packets)

        analyzer = PacketAnalyzer(save_path)
        summary = analyzer.analyze()
        f_vec = FingerprintExtractor.extract_feature_vector(summary)

        cap_id = insert_capture(
            filename=filename,
            original_name=f"Live Session ({interface}, {duration}s)",
            label=label,
            capture_time=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            packet_count=summary["total_packets"],
            file_size_bytes=summary["file_size_bytes"],
            duration=summary["duration"],
            is_synthetic=False,
            is_reference=False
        )
        store_fingerprint(cap_id, label, f_vec, summary)

        return jsonify({
            "success": True,
            "capture_id": cap_id,
            "packet_count": len(packets),
            "redirect_url": url_for("analysis", capture_id=cap_id)
        })

    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


if __name__ == "__main__":
    print(f"[*] Starting Website Fingerprinting Attack Simulator on http://{config.HOST}:{config.PORT}")
    app.run(host=config.HOST, port=config.PORT, debug=config.DEBUG)
